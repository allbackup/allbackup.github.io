# $Id$
# sample snippet from http://effbot.org/zone/wckgraph.htm

from Tkinter import *

import wckgraph
import math

root = Tk()
root.title("sine curve")

w = wckgraph.GraphWidget(root)
w.pack(fill=BOTH, expand=1)

# <i>plot a sine curve</i>
xdata = range(-360, 360+1, 2)
ydata = [math.sin(v * math.pi / 180) for v in xdata]

data = xdata, ydata

w.add(wckgraph.Axes(data))
w.add(wckgraph.LineGraph(data))

mainloop()



