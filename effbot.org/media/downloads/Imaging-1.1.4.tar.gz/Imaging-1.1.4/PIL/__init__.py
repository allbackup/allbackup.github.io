#
# The Python Imaging Library.
# $Id: //modules/pil/PIL/__init__.py#2 $
#
# package placeholder
#
# Copyright (c) 1999 by Secret Labs AB.
#
# See the README file for information on usage and redistribution.
#

# ;-)
