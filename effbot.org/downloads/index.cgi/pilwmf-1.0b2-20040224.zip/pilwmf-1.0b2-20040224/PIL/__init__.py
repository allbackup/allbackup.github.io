#
# The Python Imaging Library.
# $Id: //modules/pil/pilwmf/PIL/__init__.py#1 $
#
# package placeholder
#
# Copyright (c) 1999 by Secret Labs AB.
#
# See the README file for information on usage and redistribution.
#

# ;-)
