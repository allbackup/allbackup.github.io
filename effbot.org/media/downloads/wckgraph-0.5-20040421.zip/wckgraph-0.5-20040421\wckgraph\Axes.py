# $Id: Axes.py 104 2004-04-21 06:21:26Z fredrik $
# wck graph: standard axes
#
# Copyright (c) 2004 by Secret Labs AB
# Copyright (c) 2004 by Fredrik Lundh
#

import math
import Utils

##
# Standard axes handling.  This element sets up a drawing extent for
# subsequent elements, and also draws axes to the left and below the
# graph area.
#
# @param data Graph data.  If given, the class calculates the
#     extent from the actual graph values.  If not given, the
#     extent is taken from the <b>extent</b> option.
# @param **options Axes options.
# @keyparam extent Graph extent.
# @keyparam grid Grid pen.  If given, this should be a {@link Pen}
#     object.
# @keyparam xaxis Where to draw the x-axis.  Can be "bottom" or
#     "none".  Default is "bottom".
# @keyparam yaxis Where to draw the y-axis.  Can be one of "left",
#     "right", "both", or "none".  Default is "left".
# @keyparam xoffset Distance between the x-axis and the graph canvas.
#     Defaults to 0.
# @keyparam yoffset Distance between the y-axis and the graph canvas.
#     Defaults to 0.

class Axes:

    def __init__(self, data=None, **options):
        if data:
            extent = (
                min(data[0]), min(data[1]),
                max(data[0]), max(data[1])
                )
        else:
            extent = options.get("extent")
        self.data = data
        self.extent = extent
        self.init(**options)

    def init(self, grid=None, xaxis="bottom", yaxis="left",
             xoffset=0, yoffset=0, **options):
        self.grid = grid
        self.xaxis = xaxis
        self.yaxis = yaxis
        self.xoffset = int(xoffset)
        self.yoffset = int(yoffset)

    ##
    # Gets the current graph extent.
    #
    # @return The graph extent (xmin, ymin, xmax, ymax).

    def getextent(self):
        return self.extent

    ##
    # Sets the graph extent.
    #
    # @param extent The new extent (xmin, ymin, xmax, ymax).

    def setextent(self, extent):
        self.extent = extent

    ##
    # (Internal) Renders axes.
    #
    # @param context Graph drawing context.

    def render(self, context):

        x0, y0, x1, y1 = self.extent

        x0, x1, xaxis = self.makeaxis("x", x0, x1)
        y0, y1, yaxis = self.makeaxis("y", y0, y1)

        yaxis.reverse()

        context.extent = x0, y0, x1, y1

        # draw axes

        w, h = context.size

        xoffset = context.widget.bbox[0] + context.bbox[0]
        yoffset = context.widget.bbox[1] + context.bbox[1]

        x0, y0, x1, y1 = context.extent

        pen = context.pen(context.widget.foreground, 1)

        draw = context.widget.draw
        font = context.widget.font

        if self.grid:
            grid = self.grid.getpen(context)
        else:
            grid = None

        # horizontal axis
        if self.xaxis == "bottom":
            y = context.widget.bbox[3] + self.yoffset
            for x, label in xaxis:
                label = self.xlabel(x, label)
                x = xoffset + w * (float(x) - x0) / (x1 - x0)
                context.line(draw, (x, y, x, y+5), pen)
                if label:
                    context.text(draw, (x, y+5+2), label, font, "n")
                if grid:
                    xx = x - context.widget.bbox[0]
                    yy = context.bbox[1]
                    context.line(context.draw, (xx, yy, xx, yy+h), grid)
            if xaxis:
                context.line(draw, (xoffset, y, x, y), pen)

        # vertical axis
        if self.yaxis == "left" or self.yaxis == "both":
            x = context.widget.bbox[0] - self.yoffset
            for y, label in yaxis:
                label = self.ylabel(y, label)
                y = yoffset + h - h * (float(y) - y0) / (y1 - y0)
                context.line(draw, (x, y, x-5, y), pen)
                if label:
                    context.text(draw, (x-5-2, y), label, font, "e")
                if grid:
                    xx = context.bbox[0]
                    yy = y - context.widget.bbox[1]
                    context.line(context.draw, (xx, yy, xx+w, yy), grid)
            if yaxis:
                context.line(draw, (x-1, y, x-1, yoffset), pen)
        if self.yaxis == "right" or self.yaxis == "both":
            x = context.widget.bbox[2] + self.yoffset
            for y, label in yaxis:
                y = yoffset + h - h * (float(y) - y0) / (y1 - y0)
                context.line(draw, (x, y, x+5, y), pen)
                if label:
                    context.text(draw, (x+5+2, y), label, font, "w")
                if grid:
                    xx = context.bbox[0]
                    yy = y - context.widget.bbox[1]
                    context.line(context.draw, (xx, yy, xx+w, yy), grid)
            if yaxis:
                context.line(draw, (x, y, x, yoffset), pen)

    ##
    # (Hook) Calculates min and max values for an individual graph
    # axis, and determines where to draw tick marks.
    #
    # @param axis Axis type ("x" or "y").
    # @param lo Start of axis.
    # @param hi End of axis.
    # @return A tuple containing adjusted start and end positions,
    #     plus a list of (value, label) tick specifiers.

    def makeaxis(self, axis, lo, hi):

        # FIXME: use size of pixel canvas to determine a suitable
        # number of ticks
        ticks = 5

        w = Utils.nicenumber(hi-lo)

        d = Utils.nicenumber(w/(ticks-1), 1)

        lo = math.floor(lo/d)*d
        hi = math.ceil(hi/d)*d

        f = max(-int(math.floor(math.log10(d))), 0)

        ticks = []
        x = lo
        while x <= hi + d/2:
            ticks.append((x, "%.*f" % (f, x)))
            x = x + d

        return lo, hi, ticks

    ##
    # (Hook) Generates label for the X axis.
    #
    # @param x X value.
    # @param label Suggested label.  The default implementation simply
    #     returns this label.
    # @return The new label.  To suppress the label, return None or an
    #     empty string.

    def xlabel(self, x, label):
        return label

    ##
    # (Hook) Generates label for the Y axis.
    #
    # @param y Y value.
    # @param label Suggested label.  The default implementation simply
    #     returns this label.
    # @return The new label.  To suppress the label, return None or an
    #     empty string.

    def ylabel(self, y, label):
        return label




