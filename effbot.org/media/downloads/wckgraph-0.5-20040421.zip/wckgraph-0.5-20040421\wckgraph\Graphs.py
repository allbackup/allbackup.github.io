# $Id: Graphs.py 101 2004-04-20 22:01:14Z fredrik $
# wck graph: standard graphs
#
# Copyright (c) 2004 by Secret Labs AB
# Copyright (c) 2004 by Fredrik Lundh
#

import Utils

# TODO: add "spline" interpolation (smoothed line should intersect all
#       control points, unlike the "smooth" filter)
# TODO: make all interpolation modes available for both lines and areas
# TODO: handle non-linear axes
# TODO: add more symbols
# TODO: use different default colors depending on level (based on
#       color wheel)

##
# Pen object.  This class is used to specify pen styles for various
# drawing operations.
#
# @keyparam color Pen color.
# @keyparam width Pen width.

class Pen:

    def __init__(self, color="black", width=1):
        self.color = color
        self.width = width

    def getpen(self, context):
        if self.color:
            return context.pen(self.color, self.width)
        return None

    def line(self, context, xy):
        if self.color:
            context.draw.line(xy, self.getpen(context))


##
# Brush object.  This class is used to specify fill styles for various
# drawing operations.
#
# @keyparam color Brush color.

class Brush:

    def __init__(self, color="yellow"):
        self.color = color

    def getbrush(self, context):
        return context.brush(self.color)

    def polygon(self, context, xy, pen=None):
        if self.color:
            if pen:
                pen = pen.getpen(context)
            context.draw.polygon(xy, self.getbrush(context), pen)

    def rectangle(self, context, xy, pen=None):
        if self.color:
            if pen:
                pen = pen.getpen(context)
            context.draw.rectangle(xy, self.getbrush(context), pen)

# marker plot helpers

_plot_marker = {
    "circle": lambda d,x,y,s,b,p: (
        d.ellipse((x-s, y-s, x+s, y+s), b, p)
        ),
    "diamond": lambda d,x,y,s,b,p: (
        d.polygon((x, y-s, x+s, y, x, y+s, x-s, y), b, p)
        ),
    "minus": lambda d,x,y,s,b,p: (
        d.rectangle((x-s, y-s/2, x+s, y+s/2), b, p)
        ),
    "narrow-cross": lambda d,x,y,s,b,p: (
        d.line((x-s, y-s, x+s, y+s), p), d.line((x-s, y+s, x+s, y-s), p)
        ),
    "narrow-plus": lambda d,x,y,s,b,p: (
        d.line((x-s, y, x+s, y), p), d.line((x, y+s, x, y-s), p)
        ),
    "plus": lambda d,x,y,s,b,p: (
        d.polygon(
            (x-s/2, y-s, x+s/2, y-s, x+s/2, y-s/2, x+s, y-s/2, x+s, y+s/2,
             x+s/2, y+s/2, x+s/2, y+s, x-s/2, y+s, x-s/2, y+s/2, x-s, y+s/2,
             x-s, y-s/2, x-s/2, y-s/2), b, p
            )
        ),
    "square": lambda d,x,y,s,b,p: (
        d.rectangle((x-s, y-s, x+s, y+s), b, p)
        ),
    "triangle": lambda d,x,y,s,b,p: (
        d.polygon((x, y-s, x+s, y+s, x-s, y+s), b, p)
        ),
    }

##
# Marker object.  This is used to specify marker styles for various
# plotting operations.
#
# @keyparam style Marker style.  One of "circle", "diamond", "plus",
#     "square", or "triangle".  Defaults to "circle".
# @keyparam color Marker fill color.  Use None to draw just the border.
# @keyparam border Marker border color.
# @keyparam size Marker size (radius), in pixels.  Defaults to 5.

class Marker:

    def __init__(self, style="circle", color="blue", border="black", size=5):
        self.color = color
        self.border = border
        self.size = size
        try:
            self.plot_marker = _plot_marker[style]
        except KeyError:
            self.plot_marker = _plot_marker["circle"]

    ##
    # Plot markers on a surface.
    #
    # @param context Rendering context.
    # @param xy Coordinate array.

    def plot(self, context, xy):
        m = self.plot_marker
        d = context.draw
        s = self.size
        if self.color:
            b = context.brush(self.color)
        else:
            b = None
        if self.border:
            p = context.pen(self.border, 1)
        else:
            p = None
        for i in range(0, len(xy), 2):
            m(d, xy[i], xy[i+1], s, b, p)


##
# Base class for simple graphs.
#
# @param data Input data, given as a tuple of two arrays (xdata, ydata).
#     Both arrays should have the same length.
# @param **options Plot options.

class SimpleGraph:

    def __init__(self, data, **options):
        self.data = data

    ##
    # (Hook) Render graph in context.  The default implementation
    # maps input coordinates to pixel coordinates, relative to the
    # graph canvas, and then calls the {@link SimpleGraph.render_xy}
    # method.
    #
    # @param context Rendering context.

    def render(self, context):

        w, h = context.size

        xoffset, yoffset = context.bbox[:2]

        x0, y0, x1, y1 = context.extent

        out = []
        for x, y in zip(*self.data):
            out.append(xoffset + w * (float(x) - x0) / (x1 - x0))
            out.append(yoffset + h - h * (float(y) - y0) / (y1 - y0))

        self.render_xy(context, out)

    ##
    # (Hook) Renders graph in context.  Same as {@link SimpleGraph.render},
    # but the coordinates are given in pixel coordinates.
    #
    # @param context Rendering context.
    # @param xy Coordinate array.

    def render_xy(self, context, xy):
        pass

##
# Line plot.
#
# @param data Input data, given as a tuple of two arrays (xdata, ydata).
#     Both arrays should have the same length, and the X array should
#     be monotonically increasing (that is, xdata[i] &lt; xdata[i+1]
#     should be true for the entire array).
# @param **options Plot options.
# @keyparam pen Pen object to use when drawing the line.  Defaults to
#     a thin black line.
# @keyparam marker Marker object.  If omitted, markers are not drawn.
# @keyparam interpolation Line interpolation method.  Can be one of
#     "linear", "smooth", "stairs", "stem" or "step".  Defaults to
#     "linear".

class LineGraph(SimpleGraph):

    def __init__(self, data, **options):
        assert len(data[0]) == len(data[1])
        self.data = data
        self.init(**options)

    def init(self, pen=None, marker=None, interpolation=None, **options):
        assert isinstance(pen, Pen) or pen is None
        assert isinstance(marker, Marker) or marker is None
        self.pen = pen or Pen()
        self.marker = marker
        self.interpolation = interpolation or "linear"

    def render_xy(self, context, xy):
        if self.interpolation == "stairs":
            x0 = xy[0]; y0 = xy[1]
            for i in range(2, len(xy)-2, 2):
                x1 = xy[i]; y1 = xy[i+1]
                self.pen.line(context, (x0, y0, x1, y0, x1, y1))
                x0 = x1; y0 = y1
        elif self.interpolation == "stem":
            ymax = context.bbox[3]
            for i in range(0, len(xy), 2):
                x = xy[i]; y = xy[i+1]
                if y < ymax:
                    self.pen.line(context, (x, ymax, x, y))
        elif self.interpolation == "step":
            x0 = xy[0]; y0 = xy[1]
            for i in range(2, len(xy)-2, 2):
                x1 = xy[i]; y1 = xy[i+1]; x = (x0 + x1) / 2
                self.pen.line(context, (x0, y0, x, y0, x, y1, x1, y1))
                x0 = x1; y0 = y1
        elif self.interpolation == "smooth":
            # FIXME: change smooth to return curves, not polylines
            self.pen.line(context, Utils.smooth(xy))
        elif self.interpolation == "spline":
            # FIXME: change spline to return curves, not polylines
            self.pen.line(context, Utils.spline(xy))
        else:
            # linear
            self.pen.line(context, xy)
        if self.marker:
            self.marker.plot(context, xy)


##
# Area plot.  This is similar to {@link LineGraph}, but fills the region
# beneath the line.
#
# @param data Input data, given as a tuple of two arrays (xdata, ydata).
# @param **options Plot options.
# @keyparam brush Brush object.

class AreaGraph(SimpleGraph):

    def __init__(self, data, **options):
        assert len(data[0]) == len(data[1])
        self.data = data
        self.init(**options)

    def init(self, brush=None, **options):
        assert isinstance(brush, Brush) or brush is None
        self.brush = brush or Brush()

    def render_xy(self, context, xy):
        xy.append(xy[-2]); xy.append(context.bbox[3])
        xy.append(xy[0]); xy.append(context.bbox[3])
        self.brush.polygon(context, xy)


##
# Scatter (X-Y) plot.
#
# @param data Input data, given as a tuple of two arrays (xdata, ydata).
#     Both arrays should have the same length.
# @param **options Plot options.
# @keyparam marker Marker object.  This should be an instance of the
#     {@link Marker} class.  If omitted, a default marker style is used.

class ScatterGraph(SimpleGraph):

    def __init__(self, data, **options):
        assert len(data[0]) == len(data[1])
        self.data = data
        self.init(**options)

    def init(self, marker=None, **options):
        assert isinstance(marker, Marker) or marker is None
        self.marker = marker or Marker()

    def render_xy(self, context, xy):
        self.marker.plot(context, xy)


##
# Simple bar plot.
#
# @param data Input data, given as a tuple of two arrays (xdata, ydata).
#     Both arrays should have the same length.
# @param **options Plot options.
# @keyparam brush Brush object to use when filling the bars.  Use
#     Brush(None) to draw hollow bars.
# @keyparam pen Pen object to use for the bar border.  Use Pen(None)
#     to draw bars without a border.
# @keyparam barwidth Relative barwidth.  Defaults to 1.0 (100%).

class BarGraph(SimpleGraph):

    def __init__(self, data, **options):
        assert len(data[0]) == len(data[1])
        self.data = data
        self.init(**options)

    def init(self, brush=None, pen=None, barwidth=1.0, **options):
        self.brush = brush or Brush()
        self.pen = pen or Pen()
        self.barwidth = barwidth

    def render_xy(self, context, xy):
        w, h = context.size
        ymax = context.bbox[3]
        # assume all bars have the same width
        w = (xy[2] - xy[0]) * self.barwidth
        for i in range(0, len(xy), 2):
            x = xy[i] - w/2; y = xy[i+1]
            self.brush.rectangle(context, (x, y, x+w, ymax), self.pen)
