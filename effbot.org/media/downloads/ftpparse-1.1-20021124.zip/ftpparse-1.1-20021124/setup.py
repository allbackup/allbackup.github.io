#!/usr/bin/env python
#
# Setup script for ftpparse
# $Id: //people/fredrik/ftpparse/setup.py#1 $
#
# Usage: python setup.py install
#

from distutils.core import setup, Extension

setup(
    name="ftpparse",
    version="1.1-20021124",
    author="Fredrik Lundh",
    author_email="fredrik@pythonware.com",
    description="_ftpparse -- wrapper for Dan Bernstein's ftpparse library",
    ext_modules = [
        Extension("_ftpparse", ["_ftpparse.c", "ftpparse.c"])
        ]
    )
