from elementtree import ElementTree, XMLTreeBuilder

class NamespaceParser(XMLTreeBuilder.FancyTreeBuilder):
    def start(self, element):
        element.namespaces = self.namespaces[:]

import StringIO
file = StringIO.StringIO("""\
<soap:Envelope xmlns:soap='SOAP'>
  <soap:Body>
    <soap:Fault soap:encodingStyle='STYLE'>
      <faultcode>soap:Server</faultcode>
      <faultstring>Argument must be 100 or less.</faultstring>
      <faultactor>/system</faultactor>
      <detail xmlns:xsi='XSI' xmlns:xsd='XSD' >
        <argument xsi:type='xsd:integer'>200</argument>
        <version xsi:type='xsd:string'>2.0 beta 1</version>
      </detail>
    </soap:Fault>
  </soap:Body>
</soap:Envelope>
""")

tree = ElementTree.parse(file, NamespaceParser())

def fixqname(element, qname):
    print element.namespaces
    prefix, local = qname.split(":")
    for p, url in element.namespaces:
        if prefix == p:
            return "{%s}%s" % (url, local)
    raise SyntaxError("unknown namespace prefix (%s)" % prefix)

faultcode = tree.find(".//faultcode")
print fixqname(faultcode, faultcode.text)

for value in tree.findall(".//detail/*"):
    print fixqname(value, value.get("{XSI}type"))

ElementTree.dump(tree)
