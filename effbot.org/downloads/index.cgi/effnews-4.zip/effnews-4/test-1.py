import opml_parser, rss_parser, string
import asyncore, http_client

class http_rss_parser(rss_parser.rss_parser):

    def http_header(self, client):
        if (client.status[1] != "200" or
            client.header["content-type"] != "text/xml"):
            raise http_client.CloseConnection
        self.host = client.host

    def http_failure(self, client):
        pass

    def end_item(self):
        item = self.items[-1]
        print string.strip(item.get("title") or ""), "[%s]" % self.host
        print string.strip(item.get("link") or "")
        print
        print item.get("description")
        print

class my_opml_parser(opml_parser.opml_parser):

    def add_channel(self, title, channel):
        http_client.do_request(channel, http_rss_parser())

file = open("channels.opml")

parser = my_opml_parser()
parser.feed(file.read())
parser.close()

asyncore.loop()
