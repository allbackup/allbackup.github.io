#!/usr/bin/env python
#
# Setup script
# $Id: //modules/tkinter3000/setup.py#20 $
#
# Usage: python setup.py install
#

import os, re, sys

from glob import glob
from distutils.core import setup, Extension

import setuplib

# --------------------------------------------------------------------
# configuration.  modify as necessary

# location of the Tcl/Tk libraries (use None to search in common locations)
TCL_ROOT = None

# WCK release tag
WCK_VERSION = setuplib.find_version("WCK/__init__.py")
WCK_RELEASE = WCK_VERSION + "-" + "20031212"

# --------------------------------------------------------------------

tk = setuplib.find_tk(TCL_ROOT)

if not tk:
    print "*** cannot find Tcl/Tk headers and library files"
    print "    change the TCL_ROOT variable in the setup.py file"
    sys.exit(1)

setup(

    name="tkinter3000",
    version=WCK_RELEASE,
    author="Fredrik Lundh",
    author_email="fredrik@pythonware.com",
    url="http://www.effbot.org/zone/wck.htm",
    # download_url="http://www.effbot.org/downloads#tkinter3000",
    description="Widget Construction Kit for Tkinter",

    packages = ["WCK", "tk3"],

    scripts = glob("demo*.py") + glob("bench*.py"),

    ext_modules = [
        # wck drawing library
        Extension(
            "_tk3draw", ["_tk3draw.c"],
            include_dirs=tk.INCLUDE_DIRS,
            library_dirs=tk.LIBRARY_DIRS,
            libraries=tk.LIBRARIES
            ),
        # wck demo extension (see demoC.py)
        Extension(
            "_tk3demo", ["_tk3demo.c"]
            ),
        ]
    )
