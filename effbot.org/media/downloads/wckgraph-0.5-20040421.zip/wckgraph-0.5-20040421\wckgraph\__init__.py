# $Id: __init__.py 69 2004-04-17 19:04:57Z fredrik $
# wck graph package
#
# Copyright (c) 2004 by Secret Labs AB
# Copyright (c) 2004 by Fredrik Lundh
#

##
# The <b>wckgraph</b> package is a simple graph library for the WCK
# toolkit.  To display a diagram, first create a <b>GraphWidget</b>
# widget, and then add graph components to the diagram.
# <p>
# The following example draws a simple line diagram:
# <pre>
# graph = wckgraph.GraphWidget(root)
#
# data = xdata, ydata
#
# graph.add(wckgraph.Axes(data))
# graph.add(wckgraph.LineGraph(data))
# </pre>
#
# The <b>Axes</b> component calculates a suitable viewport based on
# the data, and also draws the axis (including labels).  The
# <b>LineGraph</b> component draws a line diagram into that viewport.
# You can use options to configure the axes and the graph components.
# <p>
# For details, see below.
##

from Widget import *

from Axes import *
from Graphs import *

