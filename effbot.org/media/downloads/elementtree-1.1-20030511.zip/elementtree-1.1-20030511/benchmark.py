# $Id: //people/fredrik/elementtree/benchmark.py#1 $
# simple elementtree benchmark program

from elementtree import XMLTreeBuilder, SimpleXMLTreeBuilder

import sys, time

try:
    file = sys.argv[1]
except IndexError:
    file = "hamlet.xml"

def benchmark(file, builder_module):
    source = open(file, "rb")
    t0 = time.time()
    parser = builder_module.TreeBuilder()
    while 1:
        data = source.read(32768)
        if not data:
            break
        parser.feed(data)
    tree = parser.close()
    t1 = time.time()
    print "%s: %d nodes read in %.3f seconds" % (
        builder_module.__name__, len(tree.getiterator()), t1-t0
        )
    raw_input("press return to continue...")

benchmark(file, XMLTreeBuilder)
benchmark(file, SimpleXMLTreeBuilder)

