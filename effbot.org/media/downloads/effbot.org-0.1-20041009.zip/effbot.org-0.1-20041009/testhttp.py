from effbot.org import http_client

import asyncore, sys

class dummy_consumer:
    def feed(self, data):
        # print "feed", repr(data)
        print "feed", repr(data[:20]), repr(data[-20:]), len(data)
    def close(self):
        print "close"
    def http(self, ok, connection, **args):
        print ok, connection, args
        print "status", connection.status
        print "header", connection.header

try:
    url = sys.argv[1]
except IndexError:
    url = "http://www.cnn.com/"

http_client.do_request(url, dummy_consumer())
http_client.do_request(url, dummy_consumer())

asyncore.loop()
p
