#!/usr/bin/env python
#
# Setup script for the elementtree library
# $Id: //people/fredrik/elementtree/setup.py#5 $
#
# Usage: python setup.py install
#

from distutils.core import setup

setup(
    name="elementtree",
    version="1.1-20030511",
    author="Fredrik Lundh",
    author_email="fredrik@pythonware.com",
    description="ElementTree - a light-weight XML object model for Python",
    packages=["elementtree"],
    )
