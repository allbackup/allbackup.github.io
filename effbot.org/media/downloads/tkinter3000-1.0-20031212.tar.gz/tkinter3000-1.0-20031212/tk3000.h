/*
 * Tkinter 3000 Widget Construction Kit
 * $Id: //modules/tkinter3000/tk3000.h#4 $
 *
 * public Tkinter 3000 WCK services
 *
 * Copyright (c) 2002 by Secret Labs AB
 * Copyright (c) 2002 by Fredrik Lundh
 */

/* make sure Python.h is included before including this file! */

#define WCK_SIMPLE_2D_API "WCKSimple2DAPI"
#define WCK_SIMPLE_2D_API_VERSION 1

typedef struct WCKSimple2DAPI {

    int version; /* should be set to WCK_SIMPLE_2D_API_VERSION */
    struct WCKSimple2DAPI *fallback;

    /* Simple2DCore.  All 2D implementations must implement
       this group of operations. */

    int (*line)(
        PyObject* draw, int x0, int y0, int x1, int y1,
        PyObject* pen
        );

    int (*rectangle)(
        PyObject* draw, int x0, int y0, int x1, int y1,
        PyObject* pen, PyObject* brush
        );

    PyObject* (*getpen)(
        PyObject* draw, int color, int width
        );

    PyObject* (*getbrush)(
        PyObject* draw, int color, int style
        );

    int (*text)(
        PyObject* draw, int x0, int y0, char* text, int textsize,
        PyObject* font
        );

    int (*textsize)(
        PyObject* draw, char* text, int textsize, PyObject* font,
        int* width, int* height
        );

    PyObject* (*getfont)(
        PyObject* draw, int color, char* fontname
        );

    /* Simple2DDraw */

    /* TBD */

} WCKSimple2DAPI;

/* -------------------------------------------------------------------- */
/* drawing helpers */

#define WCK_DRAW(api, op)\
    (*(api->op ? api->op : api->fallback->op))

#define WCK_DRAW_LINE(draw, api, xy, pen)\
    (WCK_DRAW(api, pyline)(draw, xy, pen))

#define WCK_DRAW_RECTANGLE(draw, api, xy, pen, brush)\
    (WCK_DRAW(api, pyrectangle)(draw, xy, pen, brush))

#define WCK_DRAW_TEXT(draw, api, xy, text, font)\
    (WCK_DRAW(api, pytext)(draw, xy, text, font))

#define WCK_DRAW_TEXTSIZE(draw, api, text, font)\
    (WCK_DRAW(api, pytextsize)(draw, text, font))
