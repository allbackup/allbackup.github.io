# $Id: //people/fredrik/effnews/effnews-4/http_client.py#3 $
#
# asynchronous http client (based on SimpleAsyncHTTP.py from "Python
# Standard Library" by Fredrik Lundh, O'Reilly 2001)

import asyncore
import socket, string, time
import StringIO
import mimetools, urlparse

class CloseConnection(Exception):
    pass

class async_http(asyncore.dispatcher_with_send):
    # asynchronous http client

    def __init__(self, host, port, path, consumer):
        asyncore.dispatcher_with_send.__init__(self)

        self.consumer = consumer

        self.host = host
        self.port = port
        self.path = path

        self.status = None
        self.header = None

        self.bytes_in = 0
        self.bytes_out = 0

        self.content_type = None
        self.content_length = None

        self.data = ""

        self.timestamp = time.time()

        self.create_socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connect((host, port))

    def handle_connect(self):
        # connection succeeded

        request = (
            "GET %s HTTP/1.0" % self.path,
            "Host: %s" % self.host,
            "User-Agent: effnews.py/1.0",
            "Referer: http://effbot.org/zone/effnews.htm",
            )

        request = string.join(request, "\r\n") + "\r\n\r\n"

        self.send(request)
        self.bytes_out = self.bytes_out + len(request)

    def handle_expt(self):
        # connection failed; notify consumer
        self.close()
        self.consumer.http_failed(self)

    def handle_read(self):

        data = self.recv(2048)

        self.bytes_in = self.bytes_in + len(data)

        if not self.header:
            # check if we've seen a full header

            self.data = self.data + data

            header = self.data.split("\r\n\r\n", 1)
            if len(header) <= 1:
                return
            header, data = header

            # parse header
            fp = StringIO.StringIO(header)
            self.status = fp.readline().split(" ", 2)
            self.header = mimetools.Message(fp)

            self.content_type = self.header.get("content-type")
            self.content_length = self.header.get("content-length")

            self.data = ""

            try:
                self.consumer.http_header(self)
            except CloseConnection:
                self.close()
                return

        if data:
            self.consumer.feed(data)

    def handle_close(self):
        self.consumer.close()
        self.close()

def do_request(uri, consumer):

    # turn the uri into a valid request
    scheme, host, path, params, query, fragment = urlparse.urlparse(uri)
    assert scheme == "http", "only supports HTTP requests"
    try:
        host, port = host.split(":", 1)
        port = int(port)
    except (TypeError, ValueError):
        port = 80 # default port
    if not path:
        path = "/"
    if params:
        path = path + ";" + params
    if query:
        path = path + "?" + query

    return async_http(host, port, path, consumer)
