#
# (Simple)ElementTree
# $Id: //people/fredrik/elementtree/elementtree/ElementTree.py#14 $
#
# a simple version of the effDOM ElementTree interface, based on
# xmllib.  compared to effDOM, this implementation has:
#
# - no support for observers
# - no html-specific extensions (e.g. entity preload)
# - no custom entities, doctypes, etc
# - no accelerator module
#
# history:
# 2001-10-20 fl   created (from various sources)
# 2001-11-01 fl   return root from parse method
# 2002-02-16 fl   sort attributes in lexical order
# 2002-04-06 fl   TreeBuilder refactoring, added PythonDoc markup
# 2002-05-01 fl   finished TreeBuilder refactoring
# 2002-07-14 fl   added basic namespace support to ElementTree.write
# 2002-07-25 fl   added QName attribute support
# 2002-10-20 fl   fixed encoding in write
# 2002-11-24 fl   changed default encoding to ascii; fixed attribute encoding
# 2002-11-27 fl   accept file objects or file names for parse/write
# 2002-12-04 fl   moved XMLTreeBuilder back to this module
# 2003-01-11 fl   fixed entity encoding glitch for us-ascii
# 2003-02-13 fl   added XML literal factory
# 2003-02-21 fl   added ProcessingInstruction/PI factory
# 2003-05-11 fl   added tostring/fromstring helpers
#
# Copyright (c) 1999-2003 by Fredrik Lundh.  All rights reserved.
#
# fredrik@pythonware.com
# http://www.pythonware.com
#
# --------------------------------------------------------------------
# The ElementTree toolkit is
#
# Copyright (c) 1999-2003 by Fredrik Lundh
#
# By obtaining, using, and/or copying this software and/or its
# associated documentation, you agree that you have read, understood,
# and will comply with the following terms and conditions:
#
# Permission to use, copy, modify, and distribute this software and
# its associated documentation for any purpose and without fee is
# hereby granted, provided that the above copyright notice appears in
# all copies, and that both that copyright notice and this permission
# notice appear in supporting documentation, and that the name of
# Secret Labs AB or the author not be used in advertising or publicity
# pertaining to distribution of the software without specific, written
# prior permission.
#
# SECRET LABS AB AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD
# TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANT-
# ABILITY AND FITNESS.  IN NO EVENT SHALL SECRET LABS AB OR THE AUTHOR
# BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY
# DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
# WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
# ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
# OF THIS SOFTWARE.
# --------------------------------------------------------------------

import string, sys, re

# TODO: add support for custom namespace resolvers/default namespaces
# TODO: add support for incremental parsing

##
# Internal element class.  This represents an individual element
# instance in an Element tree structure.
# <p>
# You should not create instances of this class directly.  Use the
# appropriate factory functions instead.
#
# @see Element
# @see SubElement
# @see Comment

class _Element:
    # <tag attrib>text<child/>...</tag>tail

    ##
    # Text before first subelement.  This is either a string or
    # the value None, if there was no text.

    text = None

    ##
    # Text after this element's end tag, but before the next sibling
    # element's start tag.  This is either a string or the value None,
    # if there was no text.

    tail = None # text after end tag, if any

    ##
    # Create an _Element instance.

    def __init__(self, tag, attrib):
        self.tag = tag
        self.attrib = attrib
        self._children = []

    def __repr__(self):
        return "<Element %s at %x>" % (self.tag, id(self))

    ##
    # Return the number of subelements.

    def __len__(self):
        return len(self._children)

    ##
    # Return the given subelement.
    #
    # @param index What subelement to return.
    # @throws IndexError If no matching element was found.

    def __getitem__(self, index):
        return self._children[index]

    ##
    # Replace the given subelement.
    #
    # @param index What subelement to replace.
    # @param element The new element value.
    # @throws IndexError If no matching element was found.
    # @throws AssertionError If element is not a valid object.

    def __setitem__(self, index, element):
        assert iselement(element)
        self._children[index] = element

    ##
    # Delete the given subelement.
    #
    # @param index What subelement to delete.
    # @exception IndexError If no matching element was found.

    def __delitem__(self, index):
        del self._children[index]

    ##
    # Return a list containing subelements in the given range.
    #
    # @param start The first subelement to return.
    # @param stop The first subelement that shouldn't be returned.

    def __getslice__(self, start, stop):
        return self._children[start:stop]

    ##
    # Replace a number of subelements with elements from a sequence.
    #
    # @param start The first subelement to replace.
    # @param stop The first subelement that shouldn't be replaced.
    # @param elements A sequence object with zero or more elements.
    # @throws AssertionError If a sequence member is not a valid object.

    def __setslice__(self, start, stop, elements):
        for element in elements:
            assert iselement(element)
        self._children[start:stop] = list(elements)

    ##
    # Delete a number of subelements.
    #
    # @param start The first subelement to delete.
    # @param stop The first subelement to leave in there.

    def __delslice__(self, start, stop):
        del self._children[start:stop]

    ##
    # Add a subelement to the end of the element.
    #
    # @param element The element to add.
    # @throws AssertionError If a sequence member is not a valid object.

    def append(self, element):
        assert iselement(element)
        self._children.append(element)

    ##
    # Insert a subelement at the given position.
    #
    # @param index Where to insert the new subelement.
    # @throws AssertionError If the element is not a valid object.

    def insert(self, index, element):
        assert iselement(element)
        self._children.insert(index, element)

    ##
    # Remove a matching subelement.  Unlike the <b>find</b> methods,
    # this method compares elements based on identity, not on tag
    # value or contents.
    #
    # @param element What element to remove.
    # @throws ValueError If a matching element could not be found.
    # @throws AssertionError If the element is not a valid object.

    def remove(self, element):
        assert iselement(element)
        self._children.remove(element)

    ##
    # Return all subelements.  The elements are returned in document
    # order.
    #
    # @return A list of subelements.

    def getchildren(self):
        return self._children

    ##
    # Find a subelement, by tag name.
    #
    # @param tag What element to look for.
    # @return The first matching element, or None if no element was found.

    def find(self, tag):
        for element in self._children:
            if element.tag == tag:
                return element
        return None

    ##
    # Find subelement text, by tag name.
    #
    # @param tag What element to look for.
    # @return The text content of the first matching element, or None
    #     if no element was found, or the element had no text content.

    def findtext(self, tag):
        for element in self._children:
            if element.tag == tag:
                return element.text
        return None

    ##
    # Find all subelements with a given tag name.
    #
    # @param tag What element to look for.
    # @return A list or iterator containing all matching elements,
    #    in order.

    def findall(self, tag):
        if tag[:3] == ".//":
            return self.getiterator(tag[3:])
        out = []
        for element in self._children:
            if element.tag == tag:
                out.append(element)
        return out

    ##
    # Reset an element.  This function removes all subelements, clears
    # all attributes, and sets the text and tail attributes to None.

    def clear(self):
        self.attrib.clear()
        self._children = []
        self.text = self.tail = None

    ##
    # Get an element attribute.
    #
    # @param key What attribute to look for.
    # @param default What to return if the attribute was not found.
    # @return The attribute value, or the default value, if not found.

    def get(self, key, default=None):
        return self.attrib.get(key, default)

    ##
    # Set an element attribute.
    #
    # @param key What attribute to set.
    # @param value The attribute value.

    def set(self, key, value):
        self.attrib[key] = value

    ##
    # Get a list of attribute names.  The names are returned in an
    # arbitrary order (just like for an ordinary Python dictionary).
    #
    # @return A list of element attribute names.

    def keys(self):
        return self.attrib.keys()

    ##
    # Get attributes, as a sequence.  The attributes are returned in
    # an arbitrary order.
    #
    # @return A list of (key, value) tuples for all attributes.

    def items(self):
        return self.attrib.items()

    ##
    # Create tree iterator.  The iterator loops over all subelements,
    # in document order.
    # <p>
    # If the tree structure is modified during iteration, the result
    # is undefined.
    #
    # @param tag What tags to look for (default is to return all elements).
    # @return A list or iterator containing all the matching elements.

    def getiterator(self, tag=None):
        nodes = []
        if tag is None or self.tag == tag:
            nodes.append(self)
        for node in self._children:
            nodes.extend(node.getiterator(tag))
        return nodes

##
# Element factory.  This function returns an object implementing the
# standard Element interface.  The exact class or type of that object
# is implementation dependent.
# <p>
# The element name, attribute names, and attribute values can be
# either 8-bit ASCII strings or Unicode strings.
#
# @param tag The element name.
# @param attrib An optional dictionary, containing element attributes.
# @param **extra Additional attributes, given as keyword arguments.
# @return An element instance.

def Element(tag, attrib={}, **extra):
    attrib = attrib.copy()
    attrib.update(extra)
    return _Element(tag, attrib)

##
# Subelement factory.  This function creates an element instance, and
# appends it to an existing element.
# <p>
# The element name, attribute names, and attribute values can be
# either 8-bit ASCII strings or Unicode strings.
#
# @param parent The parent element.
# @param tag The subelement name.
# @param attrib An optional dictionary, containing element attributes.
# @param **extra Additional attributes, given as keyword arguments.
# @return An element instance.

def SubElement(parent, tag, attrib={}, **extra):
    attrib = attrib.copy()
    attrib.update(extra)
    element = _Element(tag, attrib)
    parent.append(element)
    return element

##
# Comment element factory.  This factory function creates a special
# element that will be serialized as an XML comment.
# <p>
# The comment string can be either an 8-bit ASCII string or a Unicode
# string.
#
# @param text A string containing the comment string.
# @return An element instance, representing a comment.

def Comment(text=None):
    element = Element(Comment)
    element.text = text
    return element

##
# PI element factory.  This factory function creates a special element
# that will be serialized as an XML processing instruction.
#
# @param target A string containing the PI target.
# @param text A string containing the PI contents, if any.
# @return An element instance, representing a PI.

def ProcessingInstruction(target, text=None):
    element = Element(ProcessingInstruction)
    element.text = target
    if text:
        element.text = element.text + " " + text
    return element

PI = ProcessingInstruction

##
# QName wrapper.  This can be used to wrap a QName attribute value, in
# order to get proper namespace handling on output.
#
# @param text A string containing the QName value, in the form {uri}local,
#     or, if the tag argument is given, the URI part of a QName.
# @param tag Optional tag.  If given, the first argument is interpreted as
#     an URI, and this argument is interpreted as a local name.
# @return A opaque object, representing the QName.

class QName:
    def __init__(self, text_or_uri, tag=None):
        if tag:
            text_or_uri = "{%s}%s" % (text_or_uri, tag)
        self.text = text_or_uri
    def __str__(self):
        return self.text
    def __hash__(self):
        return hash(self.text)
    def __cmp__(self, other):
        if isinstance(other, QName):
            return cmp(self.text, other.text)
        return cmp(self.text, other)

##
# ElementTree wrapper class.  This class represents an entire element
# hierarchy, and adds some extra support for serialization to and from
# standard XML.

class ElementTree:

    def __init__(self, element=None, file=None):
        assert element is None or iselement(element)
        self._root = element # first node
        if file:
            self.parse(file)

    ##
    # Get the root element for this tree.
    #
    # @return An element instance.

    def getroot(self):
        return self._root

    ##
    # Replace the root element for this tree.  This discards the
    # current contents of the tree, and replaces it with the given
    # element.  Use with care.
    #
    # @param element An element instance.

    def _setroot(self, element):
        assert iselement(element)
        self._root = element

    ##
    # Load an external XML document into this element tree.
    #
    # @param source A file name or file object.
    # @param parser An optional parser instance.
    # @return The document root element.

    def parse(self, source, parser=None):
        if not hasattr(source, "read"):
            source = open(source, "rb")
        if not parser:
            parser = XMLTreeBuilder()
        while 1:
            data = source.read(32768)
            if not data:
                break
            parser.feed(data)
        self._root = parser.close()
        return self._root

    ##
    # Create a tree iterator for the root element.  The iterator loops
    # over all elements in this tree, in document order.
    #
    # @param tag What tags to look for (default is to return all elements)
    # @return An iterator.

    def getiterator(self, tag=None):
        assert self._root is not None
        return self._root.getiterator(tag)

    ##
    # Find first toplevel element with given tag.
    # Same as getroot().find(tag).
    #
    # @param tag What element to look for.
    # @return The first matching element, or None if no element was found.

    def find(self, tag):
        assert self._root is not None
        return self._root.find(tag)

    ##
    # Find all toplevel elements with given tag.
    # Same as getroot().findall(tag).
    #
    # @param tag What element to look for.
    # @return A list or iterator containing all matching elements,
    #    in order.

    def findall(self, tag):
        assert self._root is not None
        return self._root.findall(tag)

    ##
    # Find element text for first toplevel element with given tag.
    # Same as getroot().findtext(tag).
    #
    # @param tag What toplevel element to look for.
    # @return The text content of the first matching element, or None
    #     if no element was found, or the element had no text content.

    def findtext(self, tag):
        assert self._root is not None
        return self._root.findtext(tag)

    ##
    # Write the element tree contents to a file, as XML.
    #
    # @param file A file name, or a file object opened for writing.
    # @param encoding Optional output encoding (default is US-ASCII).

    def write(self, file, encoding="us-ascii"):
        assert self._root is not None
        if not hasattr(file, "write"):
            file = open(file, "wb")
        if not encoding:
            encoding = "us-ascii"
        elif encoding != "utf-8" and encoding != "us-ascii":
            file.write("<?xml version='1.0' encoding='%s'?>\n" % encoding)
        self._write(file, self._root, encoding, {})

    def _write(self, file, node, encoding, namespaces):
        # write XML to file
        tag = node.tag
        if tag is Comment:
            file.write("<!-- %s -->" % _escape_cdata(node.text, encoding))
        elif tag is ProcessingInstruction:
            file.write("<?%s?>" % _escape_cdata(node.text, encoding))
        else:
            items = node.items()
            xmlns_items = [] # new namespaces in this scope
            if isinstance(tag, QName) or tag[:1] == "{":
                tag, xmlns = fixtag(tag, namespaces)
                if xmlns: xmlns_items.append(xmlns)
            file.write("<" + tag)
            if items or xmlns_items:
                items.sort() # lexical order
                for k, v in items:
                    if isinstance(k, QName) or k[:1] == "{":
                        k, xmlns = fixtag(k, namespaces)
                        if xmlns: xmlns_items.append(xmlns)
                    if isinstance(v, QName):
                        v, xmlns = fixtag(v, namespaces)
                        if xmlns: xmlns_items.append(xmlns)
                    file.write(" %s=\"%s\"" % (k, _escape_attrib(v, encoding)))
                for k, v in xmlns_items:
                    file.write(" %s=\"%s\"" % (k, _escape_attrib(v, encoding)))
            if node.text or node:
                file.write(">")
                if node.text:
                    file.write(_escape_cdata(node.text, encoding))
                for n in node:
                    self._write(file, n, encoding, namespaces)
                file.write("</" + tag + ">")
            else:
                file.write(" />")
            for k, v in xmlns_items:
                namespaces[v] = None # don't reuse prefixes
        if node.tail:
            file.write(_escape_cdata(node.tail, encoding))

# --------------------------------------------------------------------
# helpers

##
# Check if this appears to be a valid element object.

def iselement(element):
    # FIXME: not sure about this; might be a better idea to look
    # for tag/attrib/text attributes
    return isinstance(element, _Element)

##
# Write the element tree contents to stdout.  This function should be
# used for debugging only.
# <p>
# The exact output format is implementation dependent.  In this
# version, it's written as an ordinary XML file.
#
# @param file An element tree or an individual element.

def dump(node):
    # debugging
    if not isinstance(node, ElementTree):
        node = ElementTree(node)
    node.write(sys.stdout)

def _encode(s, encoding):
    try:
        return s.encode(encoding)
    except AttributeError:
        return s # 1.5.2: assume the string uses the right encoding

if sys.version[:3] == "1.5":
    _escape = re.compile(r"[&<>\"\x80-\xff]+") # 1.5.2
else:
    _escape = re.compile(eval(r'u"[&<>\"\u0080-\uffff]+"'))

_escape_map = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
}

def _encode_entity(text, pattern=_escape):
    # map reserved and non-ascii characters to numerical entities
    def escape_entities(m, map=_escape_map):
        out = []
        append = out.append
        for char in m.group():
            text = map.get(char)
            if text is None:
                text = "&#%d;" % ord(char)
            append(text)
        return string.join(out, "")
    return _encode(pattern.sub(escape_entities, text), "ascii")

#
# the following functions assume an ascii-compatible encoding
# (or "utf-16")

def _escape_cdata(s, encoding=None, replace=string.replace):
    if encoding:
        try:
            s = _encode(s, encoding)
        except UnicodeError:
            return _encode_entity(s)
    s = replace(s, "&", "&amp;")
    s = replace(s, "<", "&lt;")
    s = replace(s, ">", "&gt;")
    return s

def _escape_attrib(s, encoding=None, replace=string.replace):
    if encoding:
        try:
            s = _encode(s, encoding)
        except UnicodeError:
            return _encode_entity(s)
    s = replace(s, "&", "&amp;")
    s = replace(s, "'", "&apos;") # FIXME: overkill
    s = replace(s, "\"", "&quot;")
    s = replace(s, "<", "&lt;")
    s = replace(s, ">", "&gt;")
    return s

def fixtag(tag, namespaces):
    # given a decorated tag (of the form {uri}tag), return
    # prefixed tag and namespace declaration, if any
    if isinstance(tag, QName):
        tag = tag.text
    namespace_uri, tag = string.split(tag[1:], "}", 1)
    prefix = namespaces.get(namespace_uri)
    if prefix is None:
        prefix = "ns%d" % len(namespaces)
        namespaces[namespace_uri] = prefix
        xmlns = ("xmlns:%s" % prefix, namespace_uri)
    else:
        xmlns = None
    return "%s:%s" % (prefix, tag), xmlns

##
# Parse an XML document into an element tree.
#
# @param source A filename or file object containing XML data.
# @param parser Deprecated.  Do not use.
# @return An ElementTree instance

def parse(source, parser=None):
    tree = ElementTree()
    tree.parse(source, parser)
    return tree

##
# Parse an XML document from a string constant.  This function can
# be used to embed "xml literals" in Python code.
#
# @param source A string containing XML data.
# @return An Element instance.

def XML(text):
    parser = XMLTreeBuilder()
    parser.feed(text)
    return parser.close()

fromstring = XML

##
# Generate string representation of an XML element, including all
# subelements.
#
# @param element An Element instance.
# @return An encoded string containing the XML data.

def tostring(element, encoding=None):
    class dummy:
        pass
    data = []
    file = dummy()
    file.write = data.append
    ElementTree(element).write(file, encoding)
    return string.join(data, "")

##
# Generic ElementTree builder.  This builder converts a sequence of
# start, data, and end method calls to a well-formed element tree.

class TreeBuilder:

    ##
    # Create tree builder.

    def __init__(self):
        self._data = [] # data collector
        self._elem = [] # element stack
        self._last = None # last element
        self._tail = None # true if we're after an end tag

    ##
    # Flush parser buffers, and return the root element.
    #
    # @return An Element instance.

    def close(self):
        assert len(self._elem) == 0, "missing end tags"
        assert self._last != None, "missing toplevel element"
        return self._last

    def _flush(self):
        if self._data:
            if self._last is not None:
                text = string.join(self._data, "")
                if self._tail:
                    assert self._last.tail is None, "internal error (tail)"
                    self._last.tail = text
                else:
                    assert self._last.text is None, "internal error (text)"
                    self._last.text = text
            self._data = []

    ##
    # Add text to the current element.
    #
    # @param data A string.

    def data(self, data):
        self._data.append(data)

    ##
    # Open a new element.
    #
    # @param tag The element name.
    # @param attrib A dictionary containing element attributes.
    # @return The opened element.

    def start(self, tag, attrs):
        self._flush()
        self._last = elem = _Element(tag, attrs)
        if self._elem:
            self._elem[-1].append(elem)
        self._elem.append(elem)
        self._tail = 0
        return elem

    ##
    # Close current element.
    #
    # @param tag The element name.
    # @return The closed element.

    def end(self, tag):
        self._flush()
        self._last = self._elem.pop()
        assert self._last.tag == tag,\
               "end tag mismatch (expected %s, got %s)" % (
                   self._last.tag, tag)
        self._tail = 1
        return self._last

##
# ElementTree builder for XML source data.
#
# @see elementtree.ElementTree

class XMLTreeBuilder:

    def __init__(self, html=0):
        from xml.parsers import expat
        self._parser = parser = expat.ParserCreate(None, "}")
        self._target = target = TreeBuilder()
        self._names = {} # name memo cache
        parser.DefaultHandler = self._default
        parser.StartElementHandler = self._start
        parser.EndElementHandler = self._end
        parser.CharacterDataHandler = self._data
        encoding = None
        if not parser.returns_unicode:
            encoding = "utf-8"
        # target.xml(encoding, None)
        self._doctype = None
        self.entity = {}

    def _fixtext(self, text):
        # convert text string to ascii, if possible
        try:
            return str(text) # what if the default encoding is changed?
        except UnicodeError:
            return text

    def _fixname(self, key):
        # expand qname, and convert name string to ascii, if possible
        try:
            name = self._names[key]
        except KeyError:
            name = key
            if "}" in name:
                name = "{" + name
            self._names[key] = name = self._fixtext(name)
        return name

    def _start(self, tag, attrib_in):
        fixname = self._fixname
        tag = fixname(tag)
        attrib = {}
        for key, value in attrib_in.items():
            attrib[fixname(key)] = self._fixtext(value)
        return self._target.start(tag, attrib)

    def _data(self, text):
        return self._target.data(self._fixtext(text))

    def _end(self, tag):
        return self._target.end(self._fixname(tag))

    def _default(self, text):
        prefix = text[:1]
        if prefix == "&":
            # deal with undefined entities
            try:
                self._target.data(self.entity[text[1:-1]])
            except KeyError:
                raise expat.error(
                    "undefined entity %s: line %d, column %d" %
                    (text, self._parser.ErrorLineNumber,
                    self._parser.ErrorColumnNumber)
                    )
        elif prefix == "<" and text[:9] == "<!DOCTYPE":
            self._doctype = [] # inside a doctype declaration
        elif self._doctype is not None:
            # parse doctype contents
            if prefix == ">":
                self._doctype = None
                return
            text = string.strip(text)
            if not text:
                return
            self._doctype.append(text)
            n = len(self._doctype)
            if n > 2:
                type = self._doctype[1]
                if type == "PUBLIC" and n == 4:
                    name, type, pubid, system = self._doctype
                elif type == "SYSTEM" and n == 3:
                    name, type, system = self._doctype
                    pubid = None
                else:
                    return
                if pubid:
                    pubid = pubid[1:-1]
                self.doctype(name, pubid, system[1:-1])
                self._doctype = None

    ##
    # Handle doctype declaration.

    def doctype(self, name, pubid, system):
        pass

    ##
    # Feed data to the parser.

    def feed(self, data):
        self._parser.Parse(data, 0)

    ##
    # Finish feeding data to the parser.

    def close(self):
        self._parser.Parse("", 1) # end of data
        tree = self._target.close()
        del self._target, self._parser # get rid of circular references
        return tree
