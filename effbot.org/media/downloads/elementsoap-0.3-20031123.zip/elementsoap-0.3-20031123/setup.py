#!/usr/bin/env python
#
# Setup script for the elementsoap library
# $Id: //modules/elementsoap/setup.py#4 $
#
# Usage: python setup.py install
#

from distutils.core import setup

setup(
    name="elementsoap",
    version="0.3-20031123",
    author="Fredrik Lundh",
    author_email="fredrik@pythonware.com",
    url="http://effbot.org/zone/element-soap.htm",
    # download_url="http://effbot.org/downloads#elementsoap",
    description="ElementSOAP - a light-weight SOAP toolkit for Python",
    license="Python (BSD style)",
    packages=["elementsoap"],
    )
