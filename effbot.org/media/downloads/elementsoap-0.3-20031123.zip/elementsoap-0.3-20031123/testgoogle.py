from elementsoap.ElementGoogle import *
from elementtree.ElementTree import dump

import os

# get google license key (tweak as necessary)
licensefile = os.path.join(os.environ["HOME"], "google.license")

licensekey = open(licensefile).read().strip()

g = GoogleService(licensekey)

if 1:
    response = g.doGoogleSearch("elementsoap", maxResults=10)
    print response.findtext("estimatedTotalResultsCount")
    for item in response.findall(".//item"):
        print item.findtext("URL"), repr(item.findtext("title"))

if 1:
    response = g.pyGoogleSearch("elementsoap", maxResults=10)
    print response

if 1:
    print g.doSpellingSuggestion("pyhton")

if 1:
    print repr(g.doGetCachedPage("online.effbot.org")[:40]), "..."
    print len(g.doGetCachedPage("online.effbot.org"))
