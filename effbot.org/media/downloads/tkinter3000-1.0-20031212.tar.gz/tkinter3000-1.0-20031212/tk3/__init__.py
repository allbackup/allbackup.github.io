#
# Tkinter 3000 -- Widget Construction Kit
# $Id: //modules/tkinter3000/tk3/__init__.py#1 $
#
# compatibility layer.  new code should import WCK instead
# (or the appropriate driver)

from WCK.wckTkinter import *
from WCK.Utils import *
