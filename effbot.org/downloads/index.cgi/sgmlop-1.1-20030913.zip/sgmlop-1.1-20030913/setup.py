#!/usr/bin/env python
#
# Setup script for sgmlop
# $Id: //modules/sgmlop/setup.py#9 $
#
# Usage: python setup.py install
#

from distutils.core import setup, Extension

setup(
    name="sgmlop",
    version="1.1-20030913",
    author="Fredrik Lundh",
    author_email="fredrik@pythonware.com",
    description="SGMLOP -- a small and fast SGML/XML parser",
    url="http://www.pythonware.com/products/xmltoolkit/",
    ext_modules = [
        Extension("sgmlop", ["sgmlop.c"])
        ]
    )
