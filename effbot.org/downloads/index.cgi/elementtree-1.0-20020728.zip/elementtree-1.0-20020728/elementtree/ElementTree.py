#
# SimpleElementTree
# $Id: //people/fredrik/elementtree/elementtree/ElementTree.py#1 $
#
# a simple version of the effDOM ElementTree interface, based on xmllib
#
# - no observers, no separate treebuilder objects
# - no html-specific extensions (entity preload)
# - no custom entities, doctypes, etc
#
# history:
# 2001-10-20 fl   created (from various sources)
# 2001-11-01 fl   return root from parse method
# 2002-02-16 fl   sort attributes in lexical order
# 2002-04-06 fl   TreeBuilder refactoring, added PythonDoc markup
# 2002-05-01 fl   finished TreeBuilder refactoring
# 2002-07-14 fl   added basic namespace support to ElementTree.write
# 2002-07-25 fl   added QName attribute support
#
# Copyright (c) 1999-2002 by Fredrik Lundh.  All rights reserved.
#
# fredrik@pythonware.com
# http://www.pythonware.com
#
# --------------------------------------------------------------------
# The (Simple)ElementTree module and the xmltoys library is
#
# Copyright (c) 1999-2002 by Fredrik Lundh
#
# By obtaining, using, and/or copying this software and/or its
# associated documentation, you agree that you have read, understood,
# and will comply with the following terms and conditions:
#
# Permission to use, copy, modify, and distribute this software and
# its associated documentation for any purpose and without fee is
# hereby granted, provided that the above copyright notice appears in
# all copies, and that both that copyright notice and this permission
# notice appear in supporting documentation, and that the name of
# Secret Labs AB or the author not be used in advertising or publicity
# pertaining to distribution of the software without specific, written
# prior permission.
#
# SECRET LABS AB AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD
# TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANT-
# ABILITY AND FITNESS.  IN NO EVENT SHALL SECRET LABS AB OR THE AUTHOR
# BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY
# DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
# WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS
# ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE
# OF THIS SOFTWARE.
# --------------------------------------------------------------------

import string, sys

##
# Internal element class.  This represents an individual element
# instance in an Element tree structure.
# <p>
# You should not create instances of this class directly.  Use the
# appropriate factory functions instead.
#
# @see Element
# @see SubElement
# @see Comment

class _Element:
    # <tag attrib>text<child/>...</tag>tail

    ##
    # Text before first subelement.  This is either a string or
    # the value None, if there was no text.

    text = None

    ##
    # Text before first subelement.  This is either a string or
    # the value None, if there was no text.

    tail = None # text after last subelement, if any

    ##
    # Create an _Element instance.

    def __init__(self, tag, attrib):
        self.tag = tag
        self.attrib = attrib
        self._children = []

    def __repr__(self):
        return "<Element %s at %x>" % (self.tag, id(self))

    ##
    # Return the number of subelements.

    def __len__(self):
        return len(self._children)

    ##
    # Return the given subelement.
    #
    # @param index What subelement to return.
    # @throws IndexError If no matching element was found.

    def __getitem__(self, index):
        return self._children[index]

    ##
    # Replace the given subelement.
    #
    # @param index What subelement to replace.
    # @param element The new element value.
    # @throws IndexError If no matching element was found.
    # @throws AssertionError If element is not a valid object.

    def __setitem__(self, index, element):
        assert isinstance(element, _Element)
        self._children[index] = element

    ##
    # Delete the given subelement.
    #
    # @param index What subelement to delete.
    # @exception IndexError If no matching element was found.

    def __delitem__(self, index):
        del self._children[index]

    ##
    # Return a list containing subelements in the given range.
    #
    # @param start The first subelement to return.
    # @param stop The first subelement that shouldn't be returned.

    def __getslice__(self, start, stop):
        return self._children[start:stop]

    ##
    # Replace a number of subelements with elements from a sequence.
    #
    # @param start The first subelement to replace.
    # @param stop The first subelement that shouldn't be replaced.
    # @param elements A sequence object with zero or more elements.
    # @throws AssertionError If a sequence member is not a valid object.

    def __setslice__(self, start, stop, elements):
        for element in elements:
            assert isinstance(element, _Element)
        self._children[start:stop] = list(elements)

    ##
    # Delete a number of subelements.
    #
    # @param start The first subelement to delete.
    # @param stop The first subelement to leave in there.

    def __delslice__(self, start, stop):
        del self._children[start:stop]

    ##
    # Add a subelement to the end of the element.
    #
    # @param element The element to add.
    # @throws AssertionError If a sequence member is not a valid object.

    def append(self, element):
        assert isinstance(element, _Element)
        self._children.append(element)

    ##
    # Insert a subelement at the given position.
    #
    # @param index Where to insert the new subelement.
    # @throws AssertionError If the element is not a valid object.

    def insert(self, index, element):
        assert isinstance(element, _Element)
        self._children.insert(index, element)

    ##
    # Remove a matching subelement.  Unlike the <b>find</b> methods,
    # this method compares elements based on identity, not on tag
    # value or contents.
    #
    # @param element What element to remove.
    # @throws ValueError If a matching element could not be found.
    # @throws AssertionError If the element is not a valid object.

    def remove(self, element):
        assert isinstance(element, _Element)
        self._children.remove(element)

    ##
    # Return all subelements.  The elements are returned in document
    # order.
    #
    # @return A list of subelements.

    def getchildren(self):
        return self._children

    ##
    # Find a subelement, by tag name.
    #
    # @param tag What tag to look for.
    # @return The first matching element, or None if no element was found.

    def find(self, tag):
        for element in self._children:
            if element.tag == tag:
                return element
        return None

    ##
    # Find subelement text, by tag name.
    #
    # @param tag What tag to look for.
    # @return The text content of the first matching element, or None
    #     if no element was found, or the element had no text content.

    def findtext(self, tag):
        for element in self._children:
            if element.tag == tag:
                return element.text
        return None

    ##
    # Find all subelements with a given tag name.
    #
    # @param tag What tag to look for.
    # @return A list or iterator containing all matching elements,
    #    in order.

    def findall(self, tag):
        if tag[:3] == ".//":
            return self.getiterator(tag[3:])
        out = []
        for element in self._children:
            if element.tag == tag:
                out.append(element)
        return out

    ##
    # Reset an element.  This function removes all subelements, clears
    # all attributes, and sets the text and tail attributes to None.

    def clear(self):
        self.attrib.clear()
        self._children = []
        self.text = self.tail = None

    ##
    # Get an element attribute.
    #
    # @param key What attribute to look for.
    # @param default What to return if the attribute was not found.
    # @return The attribute value, or the default value, if not found.

    def get(self, key, default=None):
        return self.attrib.get(key, default)

    ##
    # Set an element attribute.
    #
    # @param key What attribute to set.
    # @param value The attribute value.

    def set(self, key, value):
        self.attrib[key] = value

    ##
    # Get a list of attribute names.  The names are returned in an
    # arbitrary order (just like for an ordinary Python dictionary).
    #
    # @return A list of element attribute names.

    def keys(self):
        return self.attrib.keys()

    ##
    # Get attributes, as a sequence.  The attributes are returned in
    # an arbitrary order.
    #
    # @return A list of (key, value) tuples for all attributes.

    def items(self):
        return self.attrib.items()

    ##
    # Create tree iterator.  The iterator loops over all subelements,
    # in document order.
    #
    # @param tag What tags to look for (default is to return all elements).
    # @return A list or iterator containing all the matching elements.

    def getiterator(self, tag=None):
        nodes = []
        if tag is None or self.tag == tag:
            nodes.append(self)
        for node in self._children:
            nodes.extend(node.getiterator(tag))
        return nodes

##
# Element factory.  This function returns an object implementing the
# standard Element interface.  The exact class or type of that object
# is implementation dependent.
# <p>
# The element name, attribute names, and attribute values can be
# either 8-bit strings or Unicode strings.
#
# @param tag The element name.
# @param attrib An optional dictionary, containing element attributes.
# @param **extra Additional attributes, given as keyword arguments.
# @return An element instance.

def Element(tag, attrib={}, **extra):
    attrib = attrib.copy()
    attrib.update(extra)
    return _Element(tag, attrib)

##
# Subelement factory.  This function creates an element instance, and
# appends it to an existing element.
# <p>
# The element name, attribute names, and attribute values can be
# either 8-bit strings or Unicode strings.
#
# @param parent The parent element.
# @param tag The subelement name.
# @param attrib An optional dictionary, containing element attributes.
# @param **extra Additional attributes, given as keyword arguments.
# @return An element instance.

def SubElement(parent, tag, attrib={}, **extra):
    attrib = attrib.copy()
    attrib.update(extra)
    element = _Element(tag, attrib)
    parent.append(element)
    return element

##
# Comment element factory.  This factory function creates a special
# element that will be serialized as an XML comment.
# <p>
# The comment string can be either an 8-bit string or a Unicode string.
#
# @param text A string containing the comment string.
# @return An element instance, representing a comment.

def Comment(text=None):
    element = Element(Comment)
    element.text = text
    return element

##
# QName wrapper.  This can be used to wrap a QName attribute value, in
# order to get proper namespace handling on output.
#
# @param text A string containing the QName value, in the form {uri}local.
# @return A opaque object, representing the QName.

class QName:
    def __init__(self, text_or_uri, tag=None):
        if tag:
            text_or_uri = "{%s}%s" % (text_or_uri, tag)
        self.text = text_or_uri
    def __str__(self):
        return self.text
    def __hash__(self):
        return hash(self.text)
    def __cmp__(self, other):
        if isinstance(other, QName):
            return cmp(self.text, other.text)
        return cmp(self.text, other)

##
# ElementTree wrapper class.  This class represents an entire element
# hierarchy, and adds some extra support for serialization to and from
# standard XML.

class ElementTree:

    def __init__(self, element=None, file=None):
        assert element is None or isinstance(element, _Element)
        self._root = element # first node
        if file:
            self.parse(file)

    ##
    # Get the root element for this tree.
    #
    # @return An element instance.

    def getroot(self):
        return self._root

    ##
    # Replace the root element for this tree.  This discards the
    # current contents of the tree, and replaces it with the given
    # element.  Use with care.
    #
    # @param element An element instance.

    def _setroot(self, element):
        assert isinstance(element, _Element)
        self._root = element

    ##
    # Load an external XML document into this element tree.
    #
    # @param source A file name or file object.
    # @param parser An optional parser instance.
    # @return The document root element.

    def parse(self, source, parser=None):
        if isinstance(source, type("")):
            source = open(source, "rb")
        if not parser:
            import XMLTreeBuilder
            parser = XMLTreeBuilder.TreeBuilder()
        while 1:
            data = source.read(32768)
            if not data:
                break
            parser.feed(data)
        self._root = parser.close()
        return self._root

    ##
    # Create a tree iterator for the root element.  The iterator loops
    # over all elements in this tree, in document order.
    #
    # @param tag What tags to look for (default is to return all elements)
    # @return An iterator.

    def getiterator(self, tag=None):
        assert self._root is not None
        return self._root.getiterator(tag)

    ##
    # Write the element tree contents to a file, as XML.
    #
    # @param file A file object.
    # @param encoding Optional output encoding.

    def write(self, file, encoding=None):
        assert self._root is not None
        if encoding:
            file.write("<?xml version='1.0' encoding='%s'?>\n" % encoding)
        self._write(file, self._root, encoding, {})

    def _write(self, file, node, encoding, namespaces):
        # write XML to file
        tag = node.tag
        if tag is Comment:
            file.write("<!-- %s -->" % escape(node.text))
        else:
            items = node.items()
            xmlns_items = [] # new namespaces in this scope
            if isinstance(tag, QName) or tag[:1] == "{":
                tag, xmlns = fixtag(tag, namespaces)
                if xmlns: xmlns_items.append(xmlns)
            file.write("<" + tag)
            if items or xmlns_items:
                items.sort() # lexical order
                for k, v in items:
                    if isinstance(k, QName) or k[:1] == "{":
                        k, xmlns = fixtag(k, namespaces)
                        if xmlns: xmlns_items.append(xmlns)
                    if isinstance(v, QName):
                        v, xmlns = fixtag(v, namespaces)
                        if xmlns: xmlns_items.append(xmlns)
                    file.write(" %s=\"%s\"" % (k, escape(v)))
                for k, v in xmlns_items:
                    file.write(" %s=\"%s\"" % (k, escape(v)))
            if node.text or node:
                file.write(">")
                if node.text:
                    file.write(escape(node.text))
                for n in node:
                    self._write(file, n, encoding, namespaces)
                file.write("</" + tag + ">")
            else:
                file.write(" />")
            for k, v in xmlns_items:
                namespaces[v] = None # don't reuse prefixes
        if node.tail:
            file.write(escape(node.tail))

# --------------------------------------------------------------------
# helpers

##
# Write the element tree contents to stdout.  This function should be
# used for debugging only.
# <p>
# The exact output format is implementation dependent.  In this
# version, it's written as an ordinary XML file.
#
# @param file An element tree or an individual element.

def dump(node):
    # debugging
    if not isinstance(node, ElementTree):
        node = ElementTree(node)
    node.write(sys.stdout)

def encode(s, encoding):
    try:
        return s.encode(encoding)
    except AttributeError:
        return s # 1.5.2: assume it uses the right encoding

def escape(s, encoding=None, replace=string.replace):
    if encoding:
        s = encode(s)
    s = replace(s, "&", "&amp;")
    s = replace(s, "<", "&lt;")
    return replace(s, ">", "&gt;")

def fixtag(tag, namespaces):
    # given a decorated tag (of the form {uri}tag), return
    # prefixed tag and namespace declaration, if any
    if isinstance(tag, QName):
        tag = tag.text
    namespace_uri, tag = string.split(tag[1:], "}", 1)
    prefix = namespaces.get(namespace_uri)
    if prefix is None:
        prefix = "ns%d" % len(namespaces)
        namespaces[namespace_uri] = prefix
        xmlns = ("xmlns:%s" % prefix, namespace_uri)
    else:
        xmlns = None
    return "%s:%s" % (prefix, tag), xmlns

##
# Parse an XML document into an element tree.
#
# @param source A filename or file object containing XML data.
# @param parser Deprecated.  Do not use.
# @return An ElementTree instance

def parse(source, parser=None):
    tree = ElementTree()
    tree.parse(source, parser)
    return tree

##
# Generic ElementTree builder.  This builder converts a sequence of
# start, data, and end method calls to a well-formed element tree.

class TreeBuilder:

    def __init__(self):
        self._data = [] # data collector
        self._elem = [] # element stack
        self._last = None # last element
        self._tail = None # true if we're after an end tag

    ##
    # Flush parser buffers, and return the root element.
    #
    # @return An Element instance.

    def close(self):
        assert len(self._elem) == 0, "missing end tags"
        assert self._last != None, "missing toplevel element"
        return self._last

    def _flush(self):
        if self._data:
            if self._last is not None:
                text = string.join(self._data, "")
                if self._tail:
                    assert self._last.tail is None, "internal error (tail)"
                    self._last.tail = text
                else:
                    assert self._last.text is None, "internal error (text)"
                    self._last.text = text
            self._data = []

    ##
    # Add text to the current element.
    #
    # @param data A string.

    def data(self, data):
        self._data.append(data)

    ##
    # Open a new element.
    #
    # @param tag The element name.
    # @param attrib A dictionary containing element attributes.
    # @return The opened element.

    def start(self, tag, attrs):
        self._flush()
        self._last = elem = _Element(tag, attrs)
        if self._elem:
            self._elem[-1].append(elem)
        self._elem.append(elem)
        self._tail = 0
        return elem

    ##
    # Close current element.
    #
    # @param tag The element name.
    # @return The closed element.

    def end(self, tag):
        self._flush()
        self._last = self._elem.pop()
        assert self._last.tag == tag,\
               "end tag mismatch (expected %s, got %s)" % (
                   self._last.tag, tag)
        self._tail = 1
        return self._last

if __name__ == "__main__":
    import time
    tree = ElementTree()
    t0 = time.time()
    tree.parse(sys.argv[1])
    t0 = time.time() - t0
    n = len(tree.getiterator())
    print "loaded", n, "nodes in", round(t0, 2), "seconds"
    dump(tree)
