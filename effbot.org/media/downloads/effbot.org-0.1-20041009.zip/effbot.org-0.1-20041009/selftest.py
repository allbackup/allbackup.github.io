# $Id: selftest.py 271 2004-10-09 10:50:59Z fredrik $
# -*- coding: iso-8859-1 -*-
# effbot.org selftest program

def sanity():
    """
    >>> from effbot.org import gzip_consumer
    >>> from effbot.org import http_client, http_manager
    """

# --------------------------------------------------------------------

if __name__ == "__main__":
    import doctest, selftest
    failed, tested = doctest.testmod(selftest)
    print tested - failed, "tests ok."
