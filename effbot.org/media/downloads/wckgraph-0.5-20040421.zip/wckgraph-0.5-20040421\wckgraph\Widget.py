# $Id: Widget.py 97 2004-04-20 15:53:18Z fredrik $
# wck graph: graph widget
#
# Copyright (c) 2004 by Secret Labs AB
# Copyright (c) 2004 by Fredrik Lundh
#

# TODO: add scrollbar support (with scrollregion)

from WCK import Widget, FONT, FOREGROUND

##
# Graph widget.  To display a graph, add an axis component, and one or
# more graph components.
#
# @param master Parent widget.
# @param **options Widget options.
# @keyparam background Widget background color.
# @keyparam font Widget font.
# @keyparam foreground Widget text color.
# @keyparam canvasbackground Graph canvas background color.  Default
#     is same as the widget background.
# @keyparam height Widget height (in pixels).  Defaults to 600 pixels.
# @keyparam width Widget width (in pixels).  Defaults to 400 pixels.

class GraphWidget(Widget):

    ui_option_font = FONT

    ui_option_foreground = FOREGROUND
    ui_option_background = "white"

    ui_option_canvasbackground = ""
    ui_option_canvasforeground = "" # not used

    ui_option_width = 600
    ui_option_height = 400

    def __init__(self, master, **options):
        self.ui_init(master, options)
        self.layers = []

    ##
    # Adds a graph component to this widget.
    #
    # @param layer Layer component.

    def add(self, layer):
        self.layers.append(layer)
        self.ui_damage()

    ##
    # Removes all layers from widget.

    def clear(self):
        self.layers = []
        self.ui_damage()

    # ui implementation methods

    def ui_handle_config(self):
        self.font = self.ui_font(
            self.ui_option_foreground, self.ui_option_font
            )
        self.background = self.ui_option_background
        self.foreground = self.ui_option_foreground
        return int(self.ui_option_width), int(self.ui_option_height)

    def ui_handle_resize(self, width, height):
        self.size = width, height

    def ui_handle_clear(self, draw, x0, y0, x1, y1):
        pass

    def ui_handle_repair(self, draw, x0, y0, x1, y1):

        background = self.ui_brush(self.ui_option_background)

        width, height = self.size

        cx, cy = draw.textsize(None, self.font)

        # calculate suitable margins
        mx = cx * 6 + 8
        my = cy * 1 + 8 + 10

        w = width - 2*mx
        h = height - 2*my

        context = _DrawContext(self, (mx, my, mx+w, my+h))

        # context.widget.bbox => graph box, relative to widget
        # context.widget.draw => widget drawing context
        # context.widget.size => widget size

        # context.bbox => inner graph area (relative to context.draw)
        # context.size => inner graph size
        # context.draw => inner graph drawing context

        m = 5
        context.size = w-2*m, h-2*m

        if min(context.size) <= 0 or not self.layers:
            # don't even try to render a zero-size canvas
            draw.rectangle((x0, y0, x1, y1), background)
            return

        context.bbox = m, m, w-m, h-m
        context.draw = self.ui_pixmap(w, h)
        context.draw.rectangle((0, 0, w, h), background)

        if self.ui_option_canvasbackground:
            # fill in the canvas background
            context.draw.rectangle(
                context.bbox, self.ui_brush(self.ui_option_canvasbackground)
                )

        context.extent = None # set by axis or canvas object

        # clear *around* the canvas
        x0, y0, x1, y1 = self.bbox
        if x0 > 0:
            draw.rectangle((0, 0, x0, height), background)
        if y0 > 0:
            draw.rectangle((x0, 0, x1, y0), background)
        if y1 < height:
            draw.rectangle((x0, y1, x1, height), background)
        if x1 < width:
            draw.rectangle((x1, 0, width, height), background)

        # render component stack
        try:
            self.draw = draw
            context.level = 0
            for layer in self.layers:
                layer.render(context)
                context.level = context.level + 1
        finally:
            self.draw = None

        draw.paste(context.draw, context.widget.bbox)


##
# (Internal) Drawing context.  A fully populated instance of this
# class is passed to the graph components during drawing.

class _DrawContext:

    def __init__(self, widget, bbox):
        self.widget = widget
        self.widget.bbox = bbox

    def pen(self, color, width):
        return self.widget.ui_pen(color, width)

    def brush(self, color):
        return self.widget.ui_brush(color)

    def font(self, color, specifier):
        return self.widget.ui_font(color, specifier)

    # FIXME: refactoring in progress

    def line(self, draw, xy, pen):
        draw.line(xy, pen)

    def ellipse(self, draw, xy, brush, pen):
        draw.ellipse(xy, brush, pen)

    def rectangle(self, draw, xy, brush, pen):
        draw.rectangle(xy, brush, pen)

    def polygon(self, draw, xy, brush, pen):
        draw.polygon(xy, brush, pen)

    def text(self, draw, xy, text, font, align=None):
        if align:
            w, h = draw.textsize(text, font)
            x, y = xy
            if "w" in align:
                pass
            elif "e" in align:
                x = x - w
            else:
                x = x - w/2
            if "n" in align:
                pass
            elif "s" in align:
                y = y - h
            else:
                y = y - h/2
            xy = x, y
        draw.text(xy, text, font)
