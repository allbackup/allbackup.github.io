# $Id: demoGraph.py 96 2004-04-20 15:05:45Z fredrik $
# test script

from Tkinter import *

import wckgraph
import math

root = Tk()
root.title("wckgraph")

w = wckgraph.GraphWidget(root, font="Helvetica 10 italic")
w.pack(fill=BOTH, expand=1)

def d2r(x):
    return x * math.pi / 180

x = [v for v in range(-360*5, 360*5, 20)]
y = [math.sin(d2r(v+0.001)) / d2r(v+0.001) for v in x]

data = x, y

class myAxes(wckgraph.Axes):
    def xlabel(self, value, label):
        return label + "\xb0"

w.add(myAxes(data, yaxis="both"))
w.add(wckgraph.AreaGraph(data))
w.add(wckgraph.LineGraph(data))

mainloop()
