# $Id: //modules/elementsoap/testquote.py#1 $
# delayed stock quote demo (www.xmethods.com)

from elementsoap.ElementSOAP import *

class QuoteService(SoapService):
    url = "http://66.28.98.121:9090/soap"
    def getQuote(self, symbol):
        action = "urn:xmethods-delayed-quotes#getQuote"
        request = SoapRequest("{urn:xmethods-delayed-quotes}getQuote")
        SoapElement(request, "symbol", "string", symbol)
        response = self.call(action, request)
        return float(response.findtext("Result"))

q = QuoteService()
print q.getQuote("MSFT")
print q.getQuote("LNUX")
