# $Id: //people/fredrik/elementtree/selftest.py#1 $
# elementtree selftest program (for python 2.1)

# TODO: add more elementtree method tests
# TODO: add xml/html parsing tests
# TODO: etc

import sys

from elementtree import ElementTree
from elementtree import XMLTreeBuilder, SimpleXMLTreeBuilder
from elementtree import HTMLTreeBuilder

def parsefile():
    """
    Test parsing from file.  Note that we're opening the files in
    here; by default, the 'parse' function opens the file in binary
    mode, and doctest doesn't filter out carriage returns.

    >>> tree = ElementTree.parse(open("samples/simple.xml", "r"))
    >>> tree.write(sys.stdout)
    <root>
       <element key="value">text</element>
       <element>text</element>tail
       <empty-element />
    </root>
    >>> tree = ElementTree.parse(open("samples/simple-ns.xml", "r"))
    >>> tree.write(sys.stdout)
    <ns0:root xmlns:ns0="namespace">
       <ns0:element key="value">text</ns0:element>
       <ns0:element>text</ns0:element>tail
       <ns0:empty-element />
    </ns0:root>
    """

def simpleparsefile():
    """
    Test the xmllib-based parser.

    >>> parser = SimpleXMLTreeBuilder.TreeBuilder()
    >>> tree = ElementTree.parse(open("samples/simple.xml", "r"), parser)
    >>> tree.write(sys.stdout)
    <root>
       <element key="value">text</element>
       <element>text</element>tail
       <empty-element />
    </root>
    """

def qname():
    """
    Test QName handling.

    1) decorated tags

    >>> elem = ElementTree.Element("{uri}tag")
    >>> tree = ElementTree.ElementTree(elem)
    >>> tree.write(sys.stdout) # 1.1
    <ns0:tag xmlns:ns0="uri" />
    >>> elem = ElementTree.Element(ElementTree.QName("{uri}tag"))
    >>> tree = ElementTree.ElementTree(elem)
    >>> tree.write(sys.stdout) # 1.2
    <ns0:tag xmlns:ns0="uri" />
    >>> elem = ElementTree.Element(ElementTree.QName("uri", "tag"))
    >>> tree = ElementTree.ElementTree(elem)
    >>> tree.write(sys.stdout) # 1.3
    <ns0:tag xmlns:ns0="uri" />

    2) decorated attributes

    >>> elem.attrib["{uri}key"] = "value"
    >>> tree.write(sys.stdout) # 2.1
    <ns0:tag ns0:key="value" xmlns:ns0="uri" />

    >>> elem.attrib[ElementTree.QName("{uri}key")] = "value"
    >>> tree.write(sys.stdout) # 2.2
    <ns0:tag ns0:key="value" xmlns:ns0="uri" />

    3) decorated values are not converted by default, but the
       QName wrapper can be used for values

    >>> elem.attrib["{uri}key"] = "{uri}value"
    >>> tree.write(sys.stdout) # 3.1
    <ns0:tag ns0:key="{uri}value" xmlns:ns0="uri" />
    >>> elem.attrib["{uri}key"] = ElementTree.QName("{uri}value")
    >>> tree.write(sys.stdout) # 3.2
    <ns0:tag ns0:key="ns0:value" xmlns:ns0="uri" />

    """

if __name__ == "__main__":
    import doctest, selftest
    failed, tested = doctest.testmod(selftest)
    print tested - failed, "tests ok."
