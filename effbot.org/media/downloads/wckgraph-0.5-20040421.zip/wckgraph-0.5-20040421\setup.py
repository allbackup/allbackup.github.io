#!/usr/bin/env python
#
# Setup script for the WCK Graph library
# $Id: setup.py 97 2004-04-20 15:53:18Z fredrik $
#
# Usage: python setup.py install
#
# Copyright (c) 2004 by Secret Labs AB
# Copyright (c) 2004 by Fredrik Lundh
#

from distutils.core import setup

try:
    # add download_url syntax to distutils
    from distutils.dist import DistributionMetadata
    DistributionMetadata.download_url = None
except:
    pass

setup(
    name="wckgraph",
    version="0.5-20040421",
    author="Fredrik Lundh",
    author_email="fredrik@pythonware.com",
    url="http://www.effbot.org/zone/wckgraph.htm",
    download_url="http://www.effbot.org/downloads#wckgraph",
    description="Graph plotting library for the WCK",
    packages = ["wckgraph"],
    )
