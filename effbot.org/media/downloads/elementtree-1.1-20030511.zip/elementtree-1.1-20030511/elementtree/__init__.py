# $Id: //people/fredrik/elementtree/elementtree/__init__.py#1 $
# elementtree package
