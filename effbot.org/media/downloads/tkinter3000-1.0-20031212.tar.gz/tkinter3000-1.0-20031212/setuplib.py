# $Id: //modules/tkinter3000/setuplib.py#2 $
# Setup helpers

import os, re, sys

PY_VERSION = sys.version[0] + sys.version[2]

class Library:
    def __init__(self):
        self.INCLUDE_DIRS = []
        self.LIBRARY_DIRS = []
        self.LIBRARIES = []

##
# Locate Tcl/Tk libraries.

def find_tk(TCL_ROOT):

    import Tkinter

    lib = Library()

    TCL_VERSION = str(Tkinter.TclVersion)[:3]

    if sys.platform == "win32":
        # windows

        if TCL_ROOT:
            path = [TCL_ROOT]
        else:
            path = [
                os.path.join(sys.prefix, "Tcl"),
                os.path.join("/py" + PY_VERSION, "Tcl"),
                os.path.join("/py" + PY_VERSION, "Tcl"),
                os.path.join("/python" + PY_VERSION, "Tcl"),
                "/Tcl",
                os.path.join(os.environ.get("ProgramFiles", ""), "Tcl"),
                    os.path.join(os.environ.get("ProgramFiles", ""), "Tcl"),

                # FIXME: add more directories here?
                ]
        for root in path:
            TCL_ROOT = os.path.abspath(root)
            if os.path.isfile(os.path.join(TCL_ROOT, "include", "tk.h")):
                break
        else:
            return None

        print "using Tcl/Tk libraries at", TCL_ROOT
        print "using Tcl/Tk version", TCL_VERSION

        version = TCL_VERSION[0] + TCL_VERSION[2]

        lib.INCLUDE_DIRS = [
            os.path.join(TCL_ROOT, "include"),
            ]
        lib.LIBRARY_DIRS = [
            os.path.join(TCL_ROOT, "lib"),
            ]
        lib.LIBRARIES = ["tk" + version, "tcl" + version]

    else:
        # unix: assume libraries are installed in the default location
        lib.INCLUDE_DIRS = []
        lib.LIBRARY_DIRS = []
        lib.LIBRARIES = ["tk" + TCL_VERSION, "tcl" + TCL_VERSION]

    return lib

##
# Extract VERSION tag from file, without importing it.

def find_version(filename):
    for line in open(filename).readlines():
        m = re.search("VERSION\s*=\s*\"([^\"]+)\"", line)
        if m:
            return m.group(1)
    return None

