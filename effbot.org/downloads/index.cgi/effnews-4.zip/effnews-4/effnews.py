# $Id: //people/fredrik/effnews/effnews-4/effnews.py#1 $
# simple Tkinter front-end for the rss parser

from Tkinter import *

import http_client, http_manager
import opml_parser
import rss_parser

import sys, traceback

# --------------------------------------------------------------------
# item database

items = {}

#
# parse channels, and store item lists in the global items dictionary

class http_rss_parser(rss_parser.rss_parser):

    def __init__(self, channel):
        rss_parser.rss_parser.__init__(self)
        self._channel = channel

    def http_header(self, client):
        if (client.status[1] != "200" or
            client.header["content-type"] != "text/xml"):
            raise http_client.CloseConnection

    def http_failure(self, client):
        pass

    def end_rss(self):
        items[self._channel] = self.items
        if self._channel == current_channel:
            update_content(self._channel) # update display

# --------------------------------------------------------------------
# globals

manager = http_manager.http_manager()

if len(sys.argv) > 1:
    channels = opml_parser.load(sys.argv[1])
else:
    channels = opml_parser.load("channels.opml")

# --------------------------------------------------------------------
# create the user interface

root = Tk()
root.title("effnews")

#
# toolbar

toolbar = Frame(root)
toolbar.pack(side=TOP, fill=X)

def schedule_reloading():
    for title, channel in channels:
        manager.request(channel, http_rss_parser(channel))

b = Button(toolbar, text="reload", command=schedule_reloading)
b.pack(side=LEFT)

# channels

channel_listbox = Listbox(root, background="white")
channel_listbox.pack(side=LEFT, fill=Y)

def select_channel(event):
    selection = channel_listbox.curselection()
    if selection:
        selection = int(selection[0])
        title, channel = channels[selection]
        update_content(channel)

channel_listbox.bind("<Double-Button-1>", select_channel)

for title, channel in channels:
    channel_listbox.insert(END, title)

#
# content panel

content_pane = Text(root, wrap=WORD)
content_pane.pack(side=TOP, fill=BOTH, expand=1)

content_pane.tag_config("head", font="helvetica 12 bold", foreground="blue")
content_pane.tag_config("body", font="helvetica 10")

current_channel = None

def update_content(channel):

    global current_channel

    current_channel = channel

    # clear the text widget
    content_pane.delete(1.0, END)

    if not items.has_key(channel):
        content_pane.insert(END, "channel not loaded")
        return

    # add newsitems to the text widget
    for item in items[channel]:
        title = item.get("title")
        if title:
            content_pane.insert(END, title.strip() + "\n", "head")
        description = item.get("description")
        if description:
            content_pane.insert(END, description.strip() + "\n", "body")
        content_pane.insert(END, "\n")

# get going

schedule_reloading()

def poll_network(root):
    try:
        manager.poll(0.1)
    except:
        traceback.print_exc()
    root.after(100, poll_network, root)

poll_network(root)

if channels:
    channel_listbox.select_set(0)
    update_content(channels[0][1]) # display first channel

print len(channels), "channels"

mainloop()
