# $Id: demoGraph.py 74 2004-04-17 21:57:49Z fredrik $
# test script

from Tkinter import *

import wckgraph
import Image

# get some image (change this if necessary)
im = Image.open("/windows/zapotec.bmp")
im = im.convert("L") # convert to grayscale

root = Tk()
root.title("wckgraph histogram")

w = wckgraph.GraphWidget(root, foreground="gray")
w.pack(fill=BOTH, expand=1)

x = [x / 255.0 for x in range(256)] # normalized grayscale (0.0-1.0)
y = im.histogram()

data = x, y

w.add(wckgraph.Axes(
    data, grid=wckgraph.Pen("gray")
    ))
w.add(wckgraph.BarGraph(
    data, barwidth=1.0, pen=wckgraph.Pen(None), brush=wckgraph.Brush("#008040")
    ))

mainloop()
