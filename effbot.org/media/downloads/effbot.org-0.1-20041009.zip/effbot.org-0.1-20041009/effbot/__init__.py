# $Id: __init__.py 271 2004-10-09 10:50:59Z fredrik $
