#!/usr/bin/env python
#
# Setup script for PythonDoc 2
# $Id: setup.py 2710 2006-04-05 16:39:06Z fredrik $
#
# Usage: python setup.py install
#

from string import find, replace
from distutils.core import setup, Extension

#
# Installation sanity check.  If reading the file in text mode returns
# CRLF line endings, assume we're using a ZIP installation archive on
# a non-Windows platform.  This avoids confusing ": No such file or
# directory" messages from the shell...

repair = 0
for file in ["pythondoc.py"]:
    try:
        f = open(file, "r")
        script = f.read()
        f.close()
        if find(script, "\r\n") >= 0:
            if not repair:
                print "=== installation kit uses CRLF in scripts!"
            print "=== repairing", file
            f = open(file, "w")
            f.write(replace(script, "\r\n", "\n"))
            f.close()
            repair = repair + 1
    except IOError:
        pass

try:
    # add classifiers/download_url syntax to distutils
    from distutils.dist import DistributionMetadata
    DistributionMetadata.classifiers = None
    DistributionMetadata.download_url = None
except:
    pass

def find_version(filename):
    import re
    for line in open(filename).readlines():
        m = re.search("VERSION_DATE\s*=\s*\"([^\"]+)\"", line)
        if m:
            return m.group(1)
    return None

setup(
    name="pythondoc",
    version=find_version("pythondoc.py"),
    author="Fredrik Lundh", author_email="fredrik@pythonware.com",
    description="A Python documentation generator, inspired by JavaDoc.",
    url="http://www.effbot.org/zone/pythondoc.htm",
    download_url="http://www.effbot.org/downloads#pythondoc",
    scripts = ["pythondoc.py"],
    )
