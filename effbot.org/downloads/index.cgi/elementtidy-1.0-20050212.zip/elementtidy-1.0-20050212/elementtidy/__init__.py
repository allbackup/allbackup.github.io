# $Id: __init__.py 1764 2004-03-29 07:07:36Z fredrik $
# package marker
