# $Id: //people/fredrik/effnews/effnews-4/http_manager.py#1 $
# manage a set of http clients

import asyncore, time
import http_client

class http_manager:

    max_connections = 4
    max_size = 1000000
    max_time = 30

    def __init__(self):
        self.queue = []

    def request(self, uri, consumer):
        self.queue.append((uri, consumer))

    def poll(self, timeout=0.1):
        # sanity checks
        now = time.time()
        for channel in asyncore.socket_map.values():
            if channel.bytes_in > self.max_size:
                channel.close() # too much data
            if now - channel.timestamp > self.max_time:
                channel.close() # too slow
        # activate up to max_connections channels
        while self.queue and len(asyncore.socket_map) < self.max_connections:
            http_client.do_request(*self.queue.pop(0))
        # keep the network running
        asyncore.poll(timeout)
        # return non-zero if we should keep on polling
        return len(self.queue) or len(asyncore.socket_map)
