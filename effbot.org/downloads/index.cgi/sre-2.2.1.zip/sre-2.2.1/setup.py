#!/usr/bin/env python
#
# Setup script
# $Id: //modules/console/setup.py#3 $
#
# Usage: python setup.py install
#

import sys, os

# make sure we're not using the local SRE
try:
    import pre
    sys.modules["re"] = pre
except ImportError:
    pass

from distutils.core import setup, Extension
from glob import glob

setup(
    name="sre",
    version="2.2.1",
    author="Fredrik Lundh",
    author_email="fredrik@pythonware.com",
    maintainer="PythonWare",
    maintainer_email="info@pythonware.com",
    description="SRE -- the regular expressions engine",
    py_modules = ["sre", "sre_parse", "sre_compile", "sre_constants"],
    ext_modules = [
        Extension("_sre", ["_sre.c"])
        ]
    )
