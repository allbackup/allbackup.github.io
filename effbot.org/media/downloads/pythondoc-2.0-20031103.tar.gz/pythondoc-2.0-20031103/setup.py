#!/usr/bin/env python
#
# Setup script for PythonDoc 2.0
# $Id: //modules/pythondoc/setup.py#10 $
#
# Usage: python setup.py install
#

from distutils.core import setup, Extension

setup(
    name="pythondoc",
    version="2.0-20031103",
    author="Fredrik Lundh", author_email="fredrik@pythonware.com",
    description="A Python documentation generator, inspired by JavaDoc.",
    url="http://www.effbot.org/zone/pythondoc.htm",
    # download_url="http://www.effbot.org/downloads#pythondoc",
    scripts = ["pythondoc.py"],
    )
