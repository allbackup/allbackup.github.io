#!/usr/bin/env python
#
# Setup script for the elementsoap library
# $Id: setup.py 2924 2006-11-19 22:24:22Z fredrik $
#
# Usage: python setup.py install
#

from distutils.core import setup

try:
    # add download_url syntax to distutils
    from distutils.dist import DistributionMetadata
    DistributionMetadata.download_url = None
except:
    pass

setup(
    name="elementsoap",
    version="0.5-20061119",
    author="Fredrik Lundh",
    author_email="fredrik@pythonware.com",
    url="http://effbot.org/zone/element-soap.htm",
    download_url="http://effbot.org/downloads#elementsoap",
    description="ElementSOAP - a light-weight SOAP toolkit for Python",
    license="Python (BSD style)",
    packages=["elementsoap"],
    )
