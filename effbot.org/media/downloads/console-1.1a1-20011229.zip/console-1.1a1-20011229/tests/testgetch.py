import msvcrt

while 1:
    ch = msvcrt.getch()
    print repr(ch),
