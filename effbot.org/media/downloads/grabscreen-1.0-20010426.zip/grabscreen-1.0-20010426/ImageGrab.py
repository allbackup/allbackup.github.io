import Image
import _grabscreen

def grab(bbox=None):
    size, data = _grabscreen.grab()
    im = Image.fromstring(
        "RGB", size, data,
        # RGB, 32-bit line padding, origo in lower left corner
        "raw", "BGR", (size[0]*3 + 3) & -4, -1
        )
    if bbox:
        im = im.crop(bbox)
    return im

if __name__ == "__main__":
    grab().save("out.png")
    print "wrote out.png..."
