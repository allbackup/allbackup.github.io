# $Id: //people/fredrik/effnews/effnews-4/rss_parser.py#4 $
# simple RSS parser

import xmllib

# namespaces used for standard elements by different RSS formats
RSS_NAMESPACES = (
    "http://purl.org/rss/1.0/", # RSS 1.0
    "http://backend.userland.com/rss2", # RSS 2.0 (sometimes)
    )

class ParseError(Exception):
    pass

class rss_parser(xmllib.XMLParser):

    def __init__(self):
        xmllib.XMLParser.__init__(self)
        self.rss_version = None
        self.channel = None
        self.current = None
        self.data_tag = None
        self.data = None
        self.items = []

    def _gethandlers(self, tag):
        # check if the tag lives in a known RSS namespace
        if tag == "http://www.w3.org/1999/02/22-rdf-syntax-ns# RDF":
            # this appears to be an RDF file.  to simplify processing,
            # map this element to an "rss" element
            return self.elements.get("rss")
        try:
            namespace, tag = tag.split()
        except ValueError:
            pass # ignore
        else:
            if namespace in RSS_NAMESPACES:
                methods = self.elements.get(tag)
                if methods:
                    return methods
        return None, None

    def unknown_starttag(self, tag, attrib):
        start, end = self._gethandlers(tag)
        if start:
            start(attrib)

    def unknown_endtag(self, tag):
        start, end = self._gethandlers(tag)
        if end:
            end()

    # stuff to deal with text elements.

    def _start_data(self, tag):
        if self.current is None:
            raise ParseError("%s tag not in channel or item element" % tag)
        self.data_tag = tag
        self.data = ""

    def handle_data(self, data):
        if self.data is not None:
            self.data = self.data + data

    handle_cdata = handle_data

    def _end_data(self):
        if self.data_tag:
            self.current[self.data_tag] = self.data or ""

    # main rss structure

    def start_rss(self, attr):
        self.rss_version = attr.get("version")
        if self.rss_version is None:
            # no undecorated version attribute.  as a work-around,
            # just look at the local names
            for k, v in attr.items():
                if k.endswith(" version"):
                    self.rss_version = v
                    break

    def start_channel(self, attr):
        if self.rss_version is None:
            # no version attribute; it might still be an RSS 1.0 file.
            # check if this element has an rdf:about attribute
            if attr.get("http://www.w3.org/1999/02/22-rdf-syntax-ns# about"):
                self.rss_version = "1.0"
            else:
                raise ParseError("cannot read this RSS file")
        self.current = {}
        self.channel = self.current

    def start_item(self, attr):
        if self.rss_version is None:
            raise ParseError("cannot read this RSS file")
        self.current = {}
        self.items.append(self.current)

    # content elements

    def start_title(self, attr):
        self._start_data("title")
    end_title = _end_data

    def start_link(self, attr):
        self._start_data("link")
    end_link = _end_data

    def start_description(self, attr):
        self._start_data("description")
    end_description = _end_data

if __name__ == "__main__":
    import sys
    for filename in sys.argv[1:]:
        file = open(filename)
        try:
            parser = rss_parser()
            parser.feed(file.read())
            parser.close()
        except:
            print "=== cannot parse %s:" % filename
            print "===", sys.exc_type, sys.exc_value
        else:
            print parser.channel
            for item in parser.items:
                print item
