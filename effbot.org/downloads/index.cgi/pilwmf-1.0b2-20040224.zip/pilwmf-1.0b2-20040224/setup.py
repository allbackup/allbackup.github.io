#!/usr/bin/env python
#
# Setup script for PIL's WMF/EMF driver
# $Id: //modules/pil/pilwmf/setup.py#3 $
#
# Usage: python setup.py install
#

from distutils.core import setup, Extension

setup(
    name="pilwmf",
    description="PIL WMF/EMF driver for Windows",
    version="1.0b2-20040224",
    author="Fredrik Lundh",
    author_email="fredrik@pythonware.com",
    url="http://effbot.org/downloads#pilwmf",
    download_url="http://effbot.org/downloads#pilwmf",
    packages=["PIL"],
    ext_modules = [
        Extension(
            "_pilwmf", ["_pilwmf.c"],
            libraries=[
                "user32", "gdi32"
                ]
            )
        ]
    )
