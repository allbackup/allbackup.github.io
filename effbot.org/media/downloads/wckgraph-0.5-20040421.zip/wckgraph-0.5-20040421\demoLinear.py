# $Id: demoGraph.py 74 2004-04-17 21:57:49Z fredrik $
# test script

from Tkinter import *

import wckgraph
import math

root = Tk()
root.title("wckgraph linear regression")

##
# Linear regression graph element.  This element calcuates and draws a
# linear regression line.

class LinearRegressionGraph(wckgraph.LineGraph):

    def __init__(self, data, **options):
        # hmm.  I wonder if I got this right...
        xdata = data[0]; ydata = data[1]
        n = len(xdata)
        # calculate sums (this can be done incrementally)
        sx = sy = sxy = sx2 = sy2 = 0.0
        for i in range(n):
            x = xdata[i]; y = ydata[i]
            sx = sx + x; sy = sy + y; sxy = sxy + x * y
            sx2 = sx2 + x * x; sy2 = sy2 + y * y
        # calculate the line equation
        sxx = sx2 - sx * sx / n
        sxy = sxy - sx * sy / n
        syy = sy2 - sy * sy / n
        m = sxy / sxx
        b = sy / n - m * sx / n
        self.line_equation = m, b
        # error term (?)
        r = math.sqrt((syy - m * m * sxx) / (n - 2))
        wckgraph.LineGraph.__init__(self, data, **options)

    def render(self, context):
        # temporarily replace the dataset with a line from x0 to x1
        x0, y0, x1, y1 = context.extent
        m, b = self.line_equation
        data = self.data
        self.data = [(x0, x1), (x0*m+b, x1*m+b)]
        wckgraph.LineGraph.render(self, context)
        self.data = data

w = wckgraph.GraphWidget(root)
w.pack(fill=BOTH, expand=1)

# sample data (from a quick google search)
# FIXME: replace with better data
x = [20, 16, 20, 18, 17, 16, 15, 17, 15, 16, 15, 17, 16, 17, 14]
y = [89, 72, 93, 84, 81, 75, 70, 82, 69, 83, 80, 83, 81, 84, 76]

data = x, y

w.add(wckgraph.Axes(data, grid=wckgraph.Pen("gray")))
w.add(wckgraph.ScatterGraph(data))
w.add(LinearRegressionGraph(data, pen=wckgraph.Pen("red", 3)))

mainloop()
