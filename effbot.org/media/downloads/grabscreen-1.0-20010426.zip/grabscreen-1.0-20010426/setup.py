#!/usr/bin/env python
#
# Setup script for grabscreen
# $Id: //modules/sgmlop/setup.py#3 $
#
# Usage: python setup.py install
#

from distutils.core import setup, Extension

setup(
    name="grabscreen",
    version="1.0-20010426",
    author="Fredrik Lundh",
    author_email="fredrik@pythonware.com",
    description="ImageGrab -- PIL screen grabber for Windows",
    py_modules = [
        "ImageGrab"
        ],
    ext_modules = [
        Extension(
            "_grabscreen", ["_grabscreen.c"],
            libraries=["user32", "gdi32"]
            )
        ]
    )
