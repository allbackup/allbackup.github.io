from elementsoap.ElementSOAP import decode_element, NamespaceParser
import string

parser = NamespaceParser()
parser.feed("""\
<?xml version='1.0' encoding='UTF-8'?>
<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xsi="http://www.w3.org/1999/XMLSchema-instance" xmlns:xsd="http://www.w3.org/1999/XMLSchema">
<SOAP-ENV:Body>
<ns1:doGoogleSearchResponse xmlns:ns1="urn:GoogleSearch" SOAP-ENV:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
<return xsi:type="ns1:GoogleSearchResult">
<documentFiltering xsi:type="xsd:boolean">true</documentFiltering>
<estimatedTotalResultsCount xsi:type="xsd:int">22</estimatedTotalResultsCount>
<directoryCategories xmlns:ns2="http://schemas.xmlsoap.org/soap/encoding/" xsi:type="ns2:Array" ns2:arrayType="ns1:DirectoryCategory[0]">
</directoryCategories>
<searchTime xsi:type="xsd:double">0.051153</searchTime>
<resultElements xmlns:ns3="http://schemas.xmlsoap.org/soap/encoding/" xsi:type="ns3:Array" ns3:arrayType="ns1:ResultElement[10]">
<item xsi:type="ns1:ResultElement">
<cachedSize xsi:type="xsd:string">5k</cachedSize>
<hostName xsi:type="xsd:string"></hostName>
<snippet xsi:type="xsd:string"> &lt;b&gt;...&lt;/b&gt; Contents of downloads/&lt;b&gt;elementsoap&lt;/b&gt;-0.1-20031119.zip/README: $Id: //modules/elementsoap/testdecode.py#1 $ ==== The &lt;b&gt;elementsoap&lt;/b&gt; &lt;b&gt;...&lt;/b&gt;  </snippet>
<directoryCategory xsi:type="ns1:DirectoryCategory">
<specialEncoding xsi:type="xsd:string"></specialEncoding>
<fullViewableName xsi:type="xsd:string"></fullViewableName>
</directoryCategory>
<relatedInformationPresent xsi:type="xsd:boolean">true</relatedInformationPresent>
<directoryTitle xsi:type="xsd:string"></directoryTitle>
<summary xsi:type="xsd:string"></summary>
<URL xsi:type="xsd:string">http://effbot.org/downloads/index.cgi/elementsoap-0.1-20031119.zip/README</URL>
<title xsi:type="xsd:string">downloads.effbot.org ::: www.effbot.org</title>
</item>
<item xsi:type="ns1:ResultElement">
<cachedSize xsi:type="xsd:string">17k</cachedSize>
<hostName xsi:type="xsd:string">effbot.org</hostName>
<snippet xsi:type="xsd:string"> &lt;b&gt;...&lt;/b&gt; effnews-4.zip [7k] [readme] [contents] &lt;b&gt;elementsoap&lt;/b&gt; #. The experimental &lt;b&gt;ElementSOAP&lt;/b&gt;&lt;br&gt; toolkit contains classes to build simple SOAP 1.1 clients. &lt;b&gt;...&lt;/b&gt;  </snippet>
<directoryCategory xsi:type="ns1:DirectoryCategory">
<specialEncoding xsi:type="xsd:string"></specialEncoding>
<fullViewableName xsi:type="xsd:string"></fullViewableName>
</directoryCategory>
<relatedInformationPresent xsi:type="xsd:boolean">true</relatedInformationPresent>
<directoryTitle xsi:type="xsd:string"></directoryTitle>
<summary xsi:type="xsd:string"></summary>
<URL xsi:type="xsd:string">http://effbot.org/downloads/</URL>
<title xsi:type="xsd:string">downloads.effbot.org ::: www.effbot.org</title>
</item>
<item xsi:type="ns1:ResultElement">
<cachedSize xsi:type="xsd:string">11k</cachedSize>
<hostName xsi:type="xsd:string"></hostName>
<snippet xsi:type="xsd:string"> &lt;b&gt;...&lt;/b&gt; November 19, 2003. &lt;b&gt;elementsoap&lt;/b&gt; 0.1 [#] In case you want to play with the SOAP and&lt;br&gt; Google code below, here&amp;#39;s the official distribution kit: &lt;b&gt;ElementSOAP&lt;/b&gt; 0.1. &lt;b&gt;...&lt;/b&gt;  </snippet>
<directoryCategory xsi:type="ns1:DirectoryCategory">
<specialEncoding xsi:type="xsd:string"></specialEncoding>
<fullViewableName xsi:type="xsd:string"></fullViewableName>
</directoryCategory>
<relatedInformationPresent xsi:type="xsd:boolean">true</relatedInformationPresent>
<directoryTitle xsi:type="xsd:string"></directoryTitle>
<summary xsi:type="xsd:string"></summary>
<URL xsi:type="xsd:string">http://online.effbot.org/</URL>
<title xsi:type="xsd:string">online.effbot.org</title>
</item>
<item xsi:type="ns1:ResultElement">
<cachedSize xsi:type="xsd:string">9k</cachedSize>
<hostName xsi:type="xsd:string"></hostName>
<snippet xsi:type="xsd:string"> &lt;b&gt;...&lt;/b&gt; 2003-11-20, leo 4.1-beta-4, Leo: Literate Editor with Outlines. 2003-11-19,&lt;br&gt; &lt;b&gt;elementsoap&lt;/b&gt; 0.1-20031119, &lt;b&gt;ElementSOAP&lt;/b&gt; - a light-weight SOAP toolkit for Python. &lt;b&gt;...&lt;/b&gt;  </snippet>
<directoryCategory xsi:type="ns1:DirectoryCategory">
<specialEncoding xsi:type="xsd:string"></specialEncoding>
<fullViewableName xsi:type="xsd:string"></fullViewableName>
</directoryCategory>
<relatedInformationPresent xsi:type="xsd:boolean">true</relatedInformationPresent>
<directoryTitle xsi:type="xsd:string"></directoryTitle>
<summary xsi:type="xsd:string"></summary>
<URL xsi:type="xsd:string">http://www.python.org/pypi/</URL>
<title xsi:type="xsd:string">Python Packages Index</title>
</item>
<item xsi:type="ns1:ResultElement">
<cachedSize xsi:type="xsd:string">10k</cachedSize>
<hostName xsi:type="xsd:string"></hostName>
<snippet xsi:type="xsd:string"> &lt;b&gt;...&lt;/b&gt; leo 4.1-beta-4, Leo: Literate Editor with Outlines. &lt;b&gt;elementsoap&lt;/b&gt; 0.1-20031119,&lt;br&gt; &lt;b&gt;ElementSOAP&lt;/b&gt; - a light-weight SOAP toolkit for Python. &lt;b&gt;...&lt;/b&gt;  </snippet>
<directoryCategory xsi:type="ns1:DirectoryCategory">
<specialEncoding xsi:type="xsd:string"></specialEncoding>
<fullViewableName xsi:type="xsd:string"></fullViewableName>
</directoryCategory>
<relatedInformationPresent xsi:type="xsd:boolean">true</relatedInformationPresent>
<directoryTitle xsi:type="xsd:string"></directoryTitle>
<summary xsi:type="xsd:string"></summary>
<URL xsi:type="xsd:string">http://www.pythonology.org/</URL>
<title xsi:type="xsd:string">Pythonology</title>
</item>
<item xsi:type="ns1:ResultElement">
<cachedSize xsi:type="xsd:string">36k</cachedSize>
<hostName xsi:type="xsd:string"></hostName>
<snippet xsi:type="xsd:string"> &lt;b&gt;...&lt;/b&gt; 23:05 | Simon Willison. &lt;b&gt;elementsoap&lt;/b&gt; 0.1-20031119 &lt;b&gt;ElementSOAP&lt;/b&gt; - a light-weight&lt;br&gt; SOAP toolkit for Python 22:43 | Python Package Index. &lt;b&gt;...&lt;/b&gt;  </snippet>
<directoryCategory xsi:type="ns1:DirectoryCategory">
<specialEncoding xsi:type="xsd:string"></specialEncoding>
<fullViewableName xsi:type="xsd:string"></fullViewableName>
</directoryCategory>
<relatedInformationPresent xsi:type="xsd:boolean">true</relatedInformationPresent>
<directoryTitle xsi:type="xsd:string"></directoryTitle>
<summary xsi:type="xsd:string"></summary>
<URL xsi:type="xsd:string">http://www.mechanicalcat.net/pyblagg.html</URL>
<title xsi:type="xsd:string">Python Programmer Weblogs</title>
</item>
<item xsi:type="ns1:ResultElement">
<cachedSize xsi:type="xsd:string">12k</cachedSize>
<hostName xsi:type="xsd:string"></hostName>
<snippet xsi:type="xsd:string"> &lt;b&gt;...&lt;/b&gt; 2000-01-01. &lt;b&gt;elementsoap&lt;/b&gt; 0.1-20031119. 2003-11-19T22:43:23Z. &lt;b&gt;...&lt;/b&gt; &lt;b&gt;ElementSOAP&lt;/b&gt; -&lt;br&gt; a light-weight SOAP toolkit for Python. bzero 0.18. 2003-11-19T22:30:58Z. &lt;b&gt;...&lt;/b&gt;  </snippet>
<directoryCategory xsi:type="ns1:DirectoryCategory">
<specialEncoding xsi:type="xsd:string"></specialEncoding>
<fullViewableName xsi:type="xsd:string"></fullViewableName>
</directoryCategory>
<relatedInformationPresent xsi:type="xsd:boolean">true</relatedInformationPresent>
<directoryTitle xsi:type="xsd:string"></directoryTitle>
<summary xsi:type="xsd:string"></summary>
<URL xsi:type="xsd:string">http://users.binary.net/thehaas/rssfeed/</URL>
<title xsi:type="xsd:string">RSSDesk</title>
</item>
<item xsi:type="ns1:ResultElement">
<cachedSize xsi:type="xsd:string">17k</cachedSize>
<hostName xsi:type="xsd:string"></hostName>
<snippet xsi:type="xsd:string"> &lt;b&gt;...&lt;/b&gt; DreamFactory, Javascript, Cross-Platform. Delayed Stock Quote for &lt;b&gt;ElementSOAP&lt;/b&gt;,&lt;br&gt; Example Source, effbot, Python, Cross-Platform. Sample source for &lt;b&gt;...&lt;/b&gt;  </snippet>
<directoryCategory xsi:type="ns1:DirectoryCategory">
<specialEncoding xsi:type="xsd:string"></specialEncoding>
<fullViewableName xsi:type="xsd:string"></fullViewableName>
</directoryCategory>
<relatedInformationPresent xsi:type="xsd:boolean">true</relatedInformationPresent>
<directoryTitle xsi:type="xsd:string"></directoryTitle>
<summary xsi:type="xsd:string"></summary>
<URL xsi:type="xsd:string">http://www.xmethods.com/ve2/ViewListing.po?serviceid=2</URL>
<title xsi:type="xsd:string">www.xmethods.net</title>
</item>
<item xsi:type="ns1:ResultElement">
<cachedSize xsi:type="xsd:string">81k</cachedSize>
<hostName xsi:type="xsd:string"></hostName>
<snippet xsi:type="xsd:string"> &lt;b&gt;...&lt;/b&gt; Systems Administration. bzero 0.18 by PyPI Feed: PyPI Homepage: PyPI.&lt;br&gt; &lt;b&gt;elementsoap&lt;/b&gt; 0.1-20031119 by PyPI Feed: PyPI Homepage: PyPI. Python &lt;b&gt;...&lt;/b&gt;  </snippet>
<directoryCategory xsi:type="ns1:DirectoryCategory">
<specialEncoding xsi:type="xsd:string"></specialEncoding>
<fullViewableName xsi:type="xsd:string"></fullViewableName>
</directoryCategory>
<relatedInformationPresent xsi:type="xsd:boolean">true</relatedInformationPresent>
<directoryTitle xsi:type="xsd:string"></directoryTitle>
<summary xsi:type="xsd:string"></summary>
<URL xsi:type="xsd:string">http://webforce.at/feedreader</URL>
<title xsi:type="xsd:string">webforce.at</title>
</item>
<item xsi:type="ns1:ResultElement">
<cachedSize xsi:type="xsd:string">20k</cachedSize>
<hostName xsi:type="xsd:string"></hostName>
<snippet xsi:type="xsd:string"> &lt;b&gt;...&lt;/b&gt; PyPI recent updates §leo 4.1 beta 4 §leo 4.1-beta-4 §&lt;b&gt;elementsoap&lt;/b&gt; 0.1-20031119&lt;br&gt; §bzero 0.18 §ll-url 0.11.4 §PDO 1.2.1 §Divmod Quotient 0.8.2. &lt;b&gt;...&lt;/b&gt;  </snippet>
<directoryCategory xsi:type="ns1:DirectoryCategory">
<specialEncoding xsi:type="xsd:string"></specialEncoding>
<fullViewableName xsi:type="xsd:string"></fullViewableName>
</directoryCategory>
<relatedInformationPresent xsi:type="xsd:boolean">true</relatedInformationPresent>
<directoryTitle xsi:type="xsd:string"></directoryTitle>
<summary xsi:type="xsd:string"></summary>
<URL xsi:type="xsd:string">http://www.gembook.jp/</URL>
<title xsi:type="xsd:string">FrontPage - ウヰキエリア</title>
</item>
</resultElements>
<endIndex xsi:type="xsd:int">10</endIndex>
<searchTips xsi:type="xsd:string"></searchTips>
<searchComments xsi:type="xsd:string"></searchComments>
<startIndex xsi:type="xsd:int">1</startIndex>
<estimateIsExact xsi:type="xsd:boolean">false</estimateIsExact>
<searchQuery xsi:type="xsd:string">elementsoap</searchQuery>
</return>
</ns1:doGoogleSearchResponse>
</SOAP-ENV:Body>
</SOAP-ENV:Envelope>
""")
response = parser.close()

NS_SOAP_ENV = "{http://schemas.xmlsoap.org/soap/envelope/}"
NS_SOAP_ENC = "{http://schemas.xmlsoap.org/soap/encoding/}"
NS_XSI = "{http://www.w3.org/1999/XMLSchema-instance}"
NS_XSD = "{http://www.w3.org/1999/XMLSchema}"

body = response.find(NS_SOAP_ENV + "Body")

for elem in body.getiterator():
    type = elem.get(NS_XSI + "type")
    if type:
        elem.set(NS_XSI + "type", parser.qname(elem, type))

def decode(element):
    type = element.get(NS_XSI + "type")
    # <i>is it an array?</i>
    if type == NS_SOAP_ENC + "Array":
        value = []
        for elem in element:
            value.append(decode(elem))
        return value
    # <i>is it a primitive type?</i>
    try:
        return decode_element(element)
    except ValueError:
        if type and type.startswith(NS_XSD):
            raise # <i>unknown primitive type</i>
    # <i>assume it's a structure</i>
    value = {}
    for elem in element:
        value[elem.tag] = decode(elem)
    return value

import pprint
pprint.pprint(decode(body[0].find("return")))
