# $Id: //modules/pil/pilwmf/selftest.py#3 $
# simple selftest for the WMF driver

import Image

# use local version of WMF driver
from PIL import WmfImagePlugin

import os

wmfile = "../unittests/pil160.wmf"
emfile = "../unittests/pil160.emf"

# wmfile = "/Program/Microsoft Office/Clipart/Popular/asna.wmf"
# emfile = "test.emf"

data = open(wmfile, "rb").read()
size = 800, 800
bbox = -1766, -859, 1733, 1133

def testbinding():
    """
    Test low-level binding (sanity check).

    >>> import _pilwmf
    >>>
    >>> buffer = _pilwmf.load(data, size, bbox)
    >>> im = Image.fromstring("RGB", size, buffer,
    ...     "raw", "BGR", (size[0]*3 + 3) & -4, -1
    ... )
    >>> im.mode
    'RGB'
    >>> im.size
    (800, 800)
    >>> im.save("raw.png")

    """


def testplugin():
    """
    Test PIL plugin.

    >>> from PIL import WmfPlugin
    >>> im = Image.open(wmfile)
    >>> im.mode
    'RGB'
    >>> im.size
    (442, 249)
    >>> im.load() # required in 1.1.5a1
    >>> im.save("wmf.png")

    >>> im = Image.open(emfile)
    >>> im.mode
    'RGB'
    >>> im.size
    (32, 32)
    >>> im.load() # required in 1.1.5a1
    >>> im.save("emf.png")
    """

if __name__ == "__main__":
    # use doctest to make sure the test program behaves as documented!
    import doctest, selftest
    status = doctest.testmod(selftest)
    if status[0]:
        print "*** %s tests of %d failed." % status
    else:
        print "%s tests passed." % status[1]
