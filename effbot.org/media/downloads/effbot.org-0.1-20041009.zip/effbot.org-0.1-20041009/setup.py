#!/usr/bin/env python
#
# Setup script for the effbot.org library
# $Id: setup.py 271 2004-10-09 10:50:59Z fredrik $
#
# Usage: python setup.py install
#

from distutils.core import setup

try:
    # add classifiers and download_url syntax to distutils
    from distutils.dist import DistributionMetadata
    DistributionMetadata.classifiers = None
    DistributionMetadata.download_url = None
except:
    pass

setup(
    name="effbot.org",
    version="0.1-20041009",
    author="Fredrik Lundh",
    author_email="fredrik@pythonware.com",
    url="http://effbot.org/zone/index.htm",
    description="The effbot.org library",
    download_url="http://effbot.org/downloads#effbot.org",
    license="Python (MIT style)",
    packages=["effbot", "effbot.org"],
    platforms="Python 1.5.2 and later.",
    )
